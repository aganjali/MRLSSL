﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using MRL.SSL.CommonClasses.MathLibrary;
//using MRL.SSL.GameDefinitions;
//using MRL.SSL.AIConsole.Engine;

//namespace MRL.SSL.AIConsole.Strategies
//{
//    public class HeadingStrategy:StrategyBase
//    {
//        public override void ResetState()
//        {
//            throw new NotImplementedException();
//        }

//        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
//        {
//            throw new NotImplementedException();
//        }

//        public override void FillInformation()
//        {
//            throw new NotImplementedException();
//        }

//        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
//        {
//            throw new NotImplementedException();
//        }

//        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
//        {
//            throw new NotImplementedException();
//        }

//        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
