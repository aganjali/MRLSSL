﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class PeakAndRushStrategy:StrategyBase
    {
        const double tresh = 0.05, stuckTresh = 0.23, angleTresh = 2, waitTresh = 20, finishTresh = 100, initDist = 0.22, maxWaitTresh = 360, passSpeedTresh = 0.08, behindBallTresh = 0.07, fieldMargin = 0.12;

        bool first, firstInState, isChip, chipOrigin, shooterFirstMove, goActive, passed, inRot;
        int[] PositionersID;
        int PasserID, ShooterID, initialPosCounter, finishCounter, timeLimitCounter, RotateDelay, opp2PeakID, rotateCounter;
        Position2D PasserPos, ShooterPos, ShootTarget, PassTarget;
        Position2D[] PositionersPos;
        double PasserAng, ShooterAng, PassSpeed, KickSpeed, firstPassSpeed, secondPassSpeed;
        double[] PositionersAng;
        Syncronizer sync;

        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId, ref int shooterId)
        {
            var tmpIds = attendIds.ToList();
            int[] allIds = new int[AttendanceSize];
            for (int i = 0; i < AttendanceSize; i++)
            {
                double minDist = double.MaxValue;
                int minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                allIds[i] = minIdx;
                tmpIds.Remove(allIds[i]);
            }
            passerId = allIds[0];
            shooterId = allIds[allIds.Length - 1];
            for (int i = 1; i < allIds.Length - 1; i++)
                ids[i - 1] = allIds[i];
            return true;
        }


        public override void ResetState()
        {
            int posCount = Math.Max(AttendanceSize - 2, 0);
            PositionersID = new int[posCount];
            PositionersAng = new double[posCount];
            PositionersPos = new Position2D[posCount];
            PasserID = -1;
            ShooterID = -1;
            opp2PeakID = -1;
            PasserAng = 0;
            ShooterAng = 0;
            PassSpeed = 0;
            firstPassSpeed = 2;
            secondPassSpeed = 2;
            KickSpeed = 8;
            initialPosCounter = 0;
            finishCounter = 0;
            timeLimitCounter = 0;
            RotateDelay = 30;
            ShootTarget = Position2D.Zero;
            PassTarget = Position2D.Zero;
            chipOrigin = true;
            isChip = true;
            passed = false;
            inRot = false;
            firstInState = true;
            shooterFirstMove = true;
            goActive = false;
            rotateCounter = 2;
            if (sync != null)
                sync.Reset();
            else
                sync = new Syncronizer();
            first = true;
        }

        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.InitialState;
            InitialState = 0;
            FinalState = 4;
            TrapState = 4;
        }

        public override void FillInformation()
        {
            StrategyName = "PeakAndRush";
            AttendanceSize = 4;
            About = "this strategy will try to peak opp defnces and rush to the defence area";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            #region first
            if (first)
            {
                if (!CalculateIDs(Model, Attendance.Keys.ToList(), ref PositionersID, ref PasserID, ref ShooterID))
                    return;
                first = false;
            }
            #endregion
            #region States
            if (CurrentState == (int)State.InitialState)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PasserID].Location.DistanceFrom(PasserPos) < tresh
                    && Model.OurRobots[PositionersID[0]].Location.DistanceFrom(PositionersPos[0]) < stuckTresh
                    && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(PositionersPos[1]) < stuckTresh
                    && Model.OurRobots[ShooterID].Location.DistanceFrom(ShooterPos) < stuckTresh)
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    CurrentState = (int)State.Peak;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.Peak)
            {
                if ((opp2PeakID != -1 && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(Model.Opponents[opp2PeakID].Location) <= 0.25)
                    || (opp2PeakID == -1 && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(PositionersPos[1]) < 0.2))
                {
                    CurrentState = (int)State.Go;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if(CurrentState == (int)State.Go)
            {
                double dist, DistFromBorder;
                if (!shooterFirstMove && GameParameters.IsInDangerousZone(Model.OurRobots[ShooterID].Location,true, 0.4,out dist,out DistFromBorder))
                {
                    goActive = false;
                    CurrentState = (int)State.Active;
                }
            }
            else if (CurrentState == (int)State.Active)
            {
                timeLimitCounter++;
                if (passed)
                    finishCounter++;
                if (sync.Finished || sync.Failed || finishCounter > finishTresh || timeLimitCounter > maxWaitTresh)
                    CurrentState = (int)State.Finish;
            }
            #endregion
            #region PosesAndAngles
            if (CurrentState == (int)State.InitialState)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PasserPos = Model.BallState.Location + new Vector2D(initDist, 0);
                PasserAng = (Model.BallState.Location - PasserPos).AngleInDegrees;

                ShooterPos = new Position2D(-1.58, Math.Sign(Model.BallState.Location.Y) * 0.3);
                ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;
                //if (Model.BallState.Location.X > -2.3)
                {
                    PositionersPos[0] = Model.BallState.Location + new Vector2D(0.6, Math.Sign(Model.BallState.Location.Y) * 0.2);
                }
                //else
                //    PositionersPos[0] = Model.BallState.Location + new Vector2D(-0.6, Math.Sign(Model.BallState.Location.Y) * 0.2);

                PositionersPos[0] = MovePointToField(PositionersPos[0], fieldMargin);
                
                PositionersAng[0] = (Model.BallState.Location - PositionersPos[0]).AngleInDegrees;

                PositionersPos[1] = new Position2D(-1.85, -Math.Sign(Model.BallState.Location.Y) * 0.5);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;
            }
            else if (CurrentState == (int)State.Peak)
            {
                if (firstInState)
                {
                    opp2PeakID = FindOppID2Peak(engine, Model, ShooterID);
                    PassTarget = new Position2D(-2.5, -Math.Sign(PasserPos.Y) * 0.5);
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, isChip, true);
                    firstInState = false;
                }
                if (opp2PeakID != -1)
                {
                    double sgn = -Math.Sign(PasserPos.Y);
                    PositionersPos[1] = Model.Opponents[opp2PeakID].Location + new Vector2D(0, sgn * 0.1);
                    PositionersAng[1] = 180;
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (opp2PeakID != -1)
                {
                    double sgn = -Math.Sign(PasserPos.Y);
                    PositionersPos[1] = Model.Opponents[opp2PeakID].Location + new Vector2D(0, sgn * 0.1);
                    PositionersAng[1] = 180;
                    if (shooterFirstMove)
                    {
                        ShooterPos = new Position2D(-1.68, -Math.Sign(Model.BallState.Location.Y) * 1);
                        ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;
                    }
                    else
                    {
                        ShooterPos =PassTarget;
                        ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;
                    }
                    if (shooterFirstMove && Math.Abs(Model.OurRobots[ShooterID].Location.Y) > 0.5)
                        shooterFirstMove = false;
                }
                else
                {
                    ShooterPos = new Position2D(-2.2, Math.Sign(Model.BallState.Location.Y) * 0.3);
                    ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;
                    shooterFirstMove =false;
                }
            }
            else if (CurrentState == (int)State.Active)
            {
                double dist, DistFromBorder;
                if (GameParameters.IsInDangerousZone(Model.BallState.Location, true,0.0,out dist,out DistFromBorder))
                    goActive = true;
                if (inRot && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
            }
            #endregion
        }

        private int FindOppID2Peak(GameStrategyEngine engine, WorldModel Model, int shooterId)
        {
            List<int> ids = new List<int>();
            Obstacles obs = new Obstacles(Model);
            obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), ((engine.GameInfo.OppTeam.GoaliID.HasValue) ? new List<int>() { engine.GameInfo.OppTeam.GoaliID.Value } : null));
            int minId = -1;
            double minDist = double.MaxValue;
            foreach (var item in obs.ObstaclesList)
            {
                if (item.Value.Meet(Model.OurRobots[shooterId], new SingleObjectState(GameParameters.OppGoalCenter, Vector2D.Zero, 0), RobotParameters.OurRobotParams.Diameter / 2))
                {
                    ids.Add(item.Key - 16);
                    double d = item.Value.State.Location.DistanceFrom(Model.OurRobots[shooterId].Location);
                    if (d < minDist)
                    {
                        minDist = d;
                        minId = item.Key - 16;
                    }
                }
            }
            return minId;
        }

        private Position2D MovePointToField(Position2D p,double margin)
        {
            p.X = Math.Sign(p.X) * Math.Min(GameParameters.OurGoalCenter.X - margin, Math.Abs(p.X));
            p.Y = Math.Sign(p.Y) * Math.Min(Math.Abs(GameParameters.OurLeftCorner.Y) - margin, Math.Abs(p.Y));
            return p;
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.InitialState)
            {
                Planner.ChangeDefaulteParams(PasserID, false);
                Planner.SetParameter(PasserID, 2.5, 2);
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, true, true, true, true);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, true, true, true, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
            }
            else if (CurrentState == (int)State.Peak)
            {
                if (Planner.AddRotate(Model, PasserID, PassTarget, 0, kickPowerType.Speed, PassSpeed, isChip, rotateCounter, false).IsInRotateDelay)
                {
                    rotateCounter++;
                    inRot = true;
                }
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, false, false, false, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, true);
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (Planner.AddRotate(Model, PasserID, PassTarget, 0, kickPowerType.Speed, PassSpeed, isChip, rotateCounter, false).IsInRotateDelay)
                {
                    rotateCounter++;
                    inRot = true;
                }
                Planner.ChangeDefaulteParams(ShooterID, false);
                Planner.SetParameter(ShooterID, 6, 6);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, false, false, false, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, true);
                }
            }
            else if (CurrentState == (int)State.Active)
            {
                if (Planner.AddRotate(Model, PasserID, PassTarget, 0, kickPowerType.Speed, PassSpeed, isChip, rotateCounter, false).IsInRotateDelay)
                    inRot = true;
                if (!goActive)
                {
                    Planner.ChangeDefaulteParams(ShooterID, false);
                    Planner.SetParameter(ShooterID, 6, 6);
                    Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, false, false, false, !passed);
                }
                else
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, ShooterID, typeof(ActiveRole)))
                        Functions[ShooterID] = (eng, wmd) => GetRole<ActiveRole>(ShooterID).Perform(engine, Model, ShooterID, PasserID);

                }
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, true);
                }
            }
            return CurrentlyAssignedRoles;
        }
        enum State
        {
            InitialState,
            Peak,
            Go,
            Active,
            Finish
        }
    }
}
