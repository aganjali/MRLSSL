﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.GameDefinitions;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;
using System.Drawing;

namespace MRL.SSL.AIConsole.Strategies
{
    public class CatchAndRotateStrategy : StrategyBase
    {
        const double tresh = 0.05, stuckTresh = 0.23, angleTresh = 2, waitTresh = 20, finishTresh = 100, initDist = 0.22, maxWaitTresh = 180, passSpeedTresh = 0.08, behindBallTresh = 0.07, fieldMargin = 0.12;

        bool first, firstInState, isChip, chipOrigin, shooterFirstMove, goActive, passed, inRotate, support, active, Debug = false, mode;
        int[] PositionersID;
        int PasserID, ShooterIdx, SupporterIdx, initialPosCounter, finishCounter, timeLimitCounter, RotateDelay, rotateCounter;
        Position2D PasserPos, ShootTarget, PassTarget, SupporterPos;
        Position2D[] PositionersPos;
        double PasserAng, PassSpeed, KickSpeed, SupporterAng, RotateTeta;
        double[] PositionersAng;
        Syncronizer sync;

        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId)
        {
            var tmpIds = attendIds.ToList();
            int[] allIds = new int[AttendanceSize - 1];
            double minDist = double.MaxValue;
            int minIdx = -1;
            foreach (var item in tmpIds.ToList())
            {
                if (Model.OurRobots.ContainsKey(item) && Model.OurRobots[item].Location.DistanceFrom(Model.BallState.Location) < minDist)
                {
                    minDist = Model.OurRobots[item].Location.DistanceFrom(Model.BallState.Location);
                    minIdx = item;
                }
            }
            if (minIdx == -1)
                return false;
            passerId = minIdx;
            tmpIds.Remove(passerId);
            for (int i = 0; i < AttendanceSize - 1; i++)
            {
                minDist = double.MaxValue;
                minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                allIds[i] = minIdx;
                tmpIds.Remove(allIds[i]);
            }
            for (int i = 0; i < allIds.Length; i++)
                ids[i] = allIds[i];
            return true;
        }
        private Position2D CalculatePassTarget(GameStrategyEngine engine, WorldModel Model,int id0, int id1, ref int id,ref int supId)
        {
            double marg = 0.2;
            double sgn = Math.Sign(Model.BallState.Location.Y);
            Position2D pr = new Position2D(GameParameters.OppGoalCenter.X, GameParameters.OppGoalLeft.Y + (-1 - sgn) * marg / 2);
            Position2D pl = new Position2D(GameParameters.OppGoalCenter.X, GameParameters.OppGoalRight.Y + (1 - sgn) * marg / 2);
            Vector2D vr = pr - Model.BallState.Location;
            Vector2D vl = pl - Model.BallState.Location;
            List<Vector2D> vlist = new List<Vector2D>();
            List<Vector2D> vlist2 = new List<Vector2D>();
            List<Vector2D> vlist3 = new List<Vector2D>();
            double resol = (1.0).ToRadian();
            double angBtw = Vector2D.AngleBetweenInRadians(vr, vl);
            double angref = vl.AngleInRadians;
            Obstacles obs = new Obstacles(Model);
            obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), ((engine.GameInfo.OppTeam.GoaliID.HasValue) ? new List<int>() { engine.GameInfo.OppTeam.GoaliID.Value } : null));
            int n = (int)(angBtw / resol);
            double size = vr.Size - 1;
            for (int i = 0; i < n; i++)
            {
                Vector2D v = Vector2D.FromAngleSize(angref + i * resol, size);
                Position2D p = Model.BallState.Location + v;
                double r = GameParameters.SafeRadi(new SingleObjectState(-p, Vector2D.Zero, 0), 0.3);
                v = GameParameters.OppGoalCenter + (p - GameParameters.OppGoalCenter).GetNormalizeToCopy(r) - Model.BallState.Location;

                if (!obs.Meet(Model.BallState, new SingleObjectState(Model.BallState.Location + v, Vector2D.Zero, 0), 0.07))
                    vlist.Add(v);
                else
                {
                    int k = 0, st = 0;
                    bool b = false;
                    Vector2D tmpV = Vector2D.Zero;
                    while(k < 5)
                    {
                        k++;
                        double newSize = v.Size - k * 0.2;
                        if (newSize > 1)
                        {
                            Vector2D v2 = v.GetNormalizeToCopy(newSize);
                            if (!obs.Meet(Model.BallState, new SingleObjectState(Model.BallState.Location + v2, Vector2D.Zero, 0), 0.07))
                            {
                                vlist3.Add(v2);
                                st = 1;
                                break;
                            }
                            else if (!b && !obs.Meet(new SingleObjectState(Model.BallState.Location + v2, Vector2D.Zero, 0), 0.07))
                            {
                                tmpV = v2;
                                b = true;
                            }
                        }
                        else
                        {
                            st = -1;
                            break;
                        }
                    }
                    if ((st == -1 || (k == 5 && st != 1)) && b)
                    {
                        vlist2.Add(tmpV);
                    }
                }
                if (Debug)
                    DrawingObjects.AddObject(new Line(Model.BallState.Location, Model.BallState.Location + v), "linePass" + i);
            }
            Position2D res = new Position2D();
            if (vlist.Count == 0 && vlist2.Count == 0 && vlist3.Count == 0)
            {
                Vector2D v = Vector2D.FromAngleSize(angref + (n / 2) * resol, 1);
                Position2D p = Model.BallState.Location + v;
                double r = GameParameters.SafeRadi(new SingleObjectState(-p, Vector2D.Zero, 0), 0.3);
                v = GameParameters.OppGoalCenter + (p - GameParameters.OppGoalCenter).GetNormalizeToCopy(r) - Model.BallState.Location;
                res = Model.BallState.Location + v;
                if (Debug)
                    DrawingObjects.AddObject(new Line(Model.BallState.Location, Model.BallState.Location + v, new Pen(Color.Red, 0.03f)), "linePassRes");
            }
            else if (vlist.Count == 0 && vlist3.Count == 0)
            {
                int idx = 0;
                if (sgn == 1)
                    idx = vlist2.Count - 1;
                res = Model.BallState.Location + vlist2[idx];
                if (Debug)
                    DrawingObjects.AddObject(new Line(Model.BallState.Location, Model.BallState.Location + vlist2[idx], new Pen(Color.Red, 0.03f)), "linePassRes");
            }
            else if (vlist.Count == 0 && vlist2.Count == 0)
            {
                res = Model.BallState.Location + vlist3[vlist3.Count - 1];
                if (Debug)
                    DrawingObjects.AddObject(new Line(Model.BallState.Location, Model.BallState.Location + vlist3[vlist3.Count - 1], new Pen(Color.Red, 0.03f)));
            }
            else
            {
                res = Model.BallState.Location + vlist[vlist.Count / 2];
                if (Debug)
                    DrawingObjects.AddObject(new Line(Model.BallState.Location, Model.BallState.Location + vlist[vlist.Count / 2], new Pen(Color.Red, 0.03f)));
            }
            bool met0 = obs.Meet(Model.OurRobots[id0], new SingleObjectState(res, Vector2D.Zero, 0), 0.1);
            bool met1 = obs.Meet(Model.OurRobots[id1], new SingleObjectState(res, Vector2D.Zero, 0), 0.1);
            if (met0 && !met1)
            {
                id = 1;
                supId = 0;
            }
            else if (!met0 && met1)
            {
                id = 0;
                supId = 1;
            }
            else
            {
                id = (Model.OurRobots[id0].Location.DistanceFrom(res) < Model.OurRobots[id1].Location.DistanceFrom(res)) ? 0 : 1;
                supId = (Model.OurRobots[id0].Location.DistanceFrom(res) < Model.OurRobots[id1].Location.DistanceFrom(res)) ? 1 : 0;
            }
            return res;
        }

        public override void ResetState()
        {
            int posCount = 2;
            PositionersID = new int[posCount];
            PositionersAng = new double[posCount];
            PositionersPos = new Position2D[posCount];
            PasserID = -1;
            PasserAng = 0;
            SupporterAng = 0;
            SupporterIdx = -1;
            ShooterIdx = -1;
            PassSpeed = 0;
            KickSpeed = 8;
            initialPosCounter = 0;
            finishCounter = 0;
            timeLimitCounter = 0;
            RotateDelay = 30;
            ShootTarget = Position2D.Zero;
            PassTarget = Position2D.Zero;
            SupporterPos = Position2D.Zero;
            PasserPos = Position2D.Zero;
            chipOrigin = false;
            isChip = false;
            passed = false;
            support = false;
            firstInState = true;
            shooterFirstMove = true;
            goActive = false;
            inRotate = false;
            back = false;
            mode = true;
            rotateCounter = 0;
            RotateTeta = 30;
            if (sync != null)
                sync.Reset();
            else
                sync = new Syncronizer();
            first = true;
        }

        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.InitialState;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
        }

        public override void FillInformation()
        {
            StrategyName = "CatchAndRotate";
            AttendanceSize = 3;
            About = "this strategy will try to catch ball in front of danger zone and rotate";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        bool back ;
        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            #region First
            if (first)
            {
                if (!CalculateIDs(Model, Attendance.Keys.ToList(), ref PositionersID, ref PasserID))
                    return;
                first = false;
            }
            #endregion
            #region States
            if (CurrentState == (int)State.InitialState)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PasserID].Location.DistanceFrom(PasserPos) < tresh
                    && Model.OurRobots[PositionersID[0]].Location.DistanceFrom(PositionersPos[0]) < tresh
                    && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(PositionersPos[1]) < tresh)
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    CurrentState = (int)State.Go;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (passed)
                    finishCounter++;
                if (sync.Finished || sync.Failed || finishCounter > finishTresh)
                    CurrentState = (int)State.Finish;
            }
            #endregion
            #region PosesAndAngles
            double sgn = Math.Sign(Model.BallState.Location.Y);
            if (CurrentState == (int)State.InitialState)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PasserPos = (Model.BallState.Location - ShootTarget).GetNormalizeToCopy(initDist) + Model.BallState.Location;
                PasserAng = (ShootTarget - PasserPos).AngleInDegrees;
                PositionersPos[1] = new Position2D(-1, -sgn * 1.7);
                PositionersPos[0] = new Position2D(-1.9, sgn * 1.5);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;
                PositionersAng[0] = (ShootTarget - PositionersPos[0]).AngleInDegrees;
                if (Model.BallState.Location.X < 1)
                {
                    mode = false;
                    back = false;
                }
                else
                    back = true;
                if (!back)
                    chipOrigin = true;
            }
            else if (CurrentState == (int)State.Go)
            {
                if (firstInState)
                {
                    PassTarget = CalculatePassTarget(engine, Model, PositionersID[0], PositionersID[1], ref ShooterIdx, ref SupporterIdx);
                    PositionersPos[ShooterIdx] = PassTarget;
                    PositionersAng[ShooterIdx] = (Model.BallState.Location - PassTarget).AngleInDegrees;
                  
                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;
                   
                    if (mode)
                    {
                        PassTarget = PositionersPos[SupporterIdx];
                        PositionersAng[SupporterIdx] = (Model.BallState.Location - PassTarget).AngleInDegrees;
                    }
                    isChip = chipOrigin;
                    firstInState = false;
                }
                if (inRotate && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                if (!passed)
                {
                    if (!chipOrigin)
                    {
                        Obstacles obs = new Obstacles(Model);
                        obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), null);
                        isChip = obs.Meet(Model.BallState, new SingleObjectState(PassTarget, Vector2D.Zero, 0), 0.07);
                    }
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, isChip, false);
                    if (isChip)
                    {
                        if (back)
                            PassSpeed = Model.BallState.Location.DistanceFrom(PassTarget) * 0.6;
                        else
                            PassSpeed = Model.BallState.Location.DistanceFrom(PassTarget) ;
                    }
                }
                if (passed && (Model.BallState.Location.X < 0.7))
                    support = true;
                if(passed)
                {
                    PasserPos = Position2D.Zero;
                    PasserAng = (Model.BallState.Location - PasserPos).AngleInDegrees;
                }
                if (passed 
                    && (/*(!mode && Model.BallState.Location.DistanceFrom(Model.OurRobots[PositionersID[ShooterIdx]].Location) < 0.5) 
                    || (mode && */(Model.OurRobots[PositionersID[SupporterIdx]].Location.X) - Model.BallState.Location.X  > 0.05)/*)*/)
                    active = true;
            }
            #endregion
        }
        
        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.InitialState)
            {
                Planner.ChangeDefaulteParams(PasserID, false);
                Planner.SetParameter(PasserID, 2.5, 2);
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, true, true, true, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (Model.OurRobots[PositionersID[ShooterIdx]].Location.DistanceFrom(PassTarget) > tresh && rotateCounter < 120)
                {
                    rotateCounter++;
                
                }
                int idxa = (!mode) ? ShooterIdx : SupporterIdx;
     
                if (passed && !active)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[idxa], typeof(CatchAndRotateBallRole)))
                        Functions[PositionersID[idxa]] = (eng, wmd) => GetRole<CatchAndRotateBallRole>(PositionersID[idxa]).CatchAndRotate(engine, Model, PositionersID[idxa], ShootTarget, isChip, false, true, KickSpeed);
                }
                else if (!active)
                {
                    Planner.ChangeDefaulteParams(PositionersID[idxa], false);
                    Planner.SetParameter(PositionersID[idxa], 7, 6);
                    Planner.Add(PositionersID[idxa], PositionersPos[idxa], PositionersAng[idxa], PathType.UnSafe, false, true, false, true);
                    if (!mode)
                    {

                        if (Planner.AddRotate(Model, PasserID, PassTarget, 0, kickPowerType.Speed, PassSpeed, isChip, Math.Max(rotateCounter, RotateDelay), false).IsInRotateDelay)
                            inRotate = true;
                    }
                }
                else
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[idxa], typeof(ActiveRole)))
                        Functions[PositionersID[idxa]] = (eng, wmd) => GetRole<ActiveRole>(PositionersID[idxa]).Perform(engine, Model, PositionersID[idxa], PasserID);
                }

                
                if (support)
                {
                    if (!mode)
                    {
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[SupporterIdx], typeof(SupporterRole)))
                            Functions[PositionersID[SupporterIdx]] = (eng, wmd) => GetRole<SupporterRole>(PositionersID[SupporterIdx]).Perform(engine, Model, PositionersID[SupporterIdx]);
                    }
                    else
                    {
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PasserID, typeof(SupporterRole)))
                            Functions[PasserID] = (eng, wmd) => GetRole<SupporterRole>(PasserID).Perform(engine, Model, PasserID);
                    }
                }
                else
                {
                    if (!mode)
                    {
                        Planner.Add(PositionersID[SupporterIdx], PositionersPos[SupporterIdx], PositionersAng[SupporterIdx], PathType.UnSafe, false, true, false, true);
                    }
                    else
                    {
                        if (passed)
                            Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, false, true, false, true);
                        else
                        {
                            if (Planner.AddRotate(Model, PasserID, PassTarget, 0, kickPowerType.Speed, PassSpeed, isChip, Math.Max(rotateCounter, RotateDelay), false).IsInRotateDelay)
                                inRotate = true;
                        }
                        Planner.ChangeDefaulteParams(PositionersID[ShooterIdx], false);
                        Planner.SetParameter(PositionersID[ShooterIdx], 7, 6);
                        Planner.Add(PositionersID[ShooterIdx], PositionersPos[ShooterIdx], PositionersAng[ShooterIdx], PathType.UnSafe, false, true, false, true);
                
                    }
                }
            }
            return CurrentlyAssignedRoles;
        }
       
        enum State
        {
            InitialState,
            Go,
            Finish
        }
    }
}
