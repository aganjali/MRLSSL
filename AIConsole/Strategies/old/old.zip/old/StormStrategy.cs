﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class StormStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        bool first = true;
        Synchronizer sync = new Synchronizer();
        int passerID = 0;
        int cutter1ID = 0;
        int cutter2ID = 0;
        int onetouchID = 0;

        Position2D passPos = new Position2D(-1.5, 1.8);
        
        Position2D passerPos = Position2D.Zero;

        Position2D cutter1Pos = new Position2D(2.5, 1.1);
        Position2D cutter2Pos = new Position2D(2.5, -1.1);

        Position2D otFirstPos = new Position2D(-2.5, 1.7);
        Position2D onetouchPos = Position2D.Zero;

        double passerAngle = 0;
        double cutter1Angle = 0;
        double cutter2Angle = 0;
        double onetouchAngle = 0;

        bool gotouch = false;
        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            sync.Reset();
            first = true;
            isInint = false;
            gotouch = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.First;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }

        public override void FillInformation()
        {
            StrategyName = "Storm";
            AttendanceSize = 4;
            About = "this Storm strategy will setup a storm to swallow skuba and immortal!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        Random rand = new Random();
        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            if (first)
            {
                double r = rand.NextDouble();
                r = (r > 0.5) ? 1 : -1;
                
                cutter1Pos.Y = -r * Math.Sign(Model.BallState.Location.Y) * Math.Abs(cutter1Pos.Y);
                cutter2Pos.Y = r * Math.Sign(Model.BallState.Location.Y) * Math.Abs(cutter2Pos.Y);

                otFirstPos.Y = -Math.Sign(Model.BallState.Location.Y) * Math.Abs(otFirstPos.Y);
                passPos.Y = -Math.Sign(Model.BallState.Location.Y) * Math.Abs(passPos.Y);
                cutter1Angle = (GameParameters.OppGoalCenter - cutter1Pos).AngleInDegrees;
                cutter2Angle = (GameParameters.OppGoalCenter - cutter2Pos).AngleInDegrees;

                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && otFirstPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = otFirstPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                onetouchID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && item.Key != onetouchID && cutter1Pos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = cutter1Pos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                cutter1ID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w != onetouchID && w!= cutter1ID).ToList();
                if (list.Count > 0)
                    cutter2ID = list[0];
                
                first = false;
            }
            if (CurrentState == (int)State.First)
            {
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutter1ID].Location.DistanceFrom(cutter1Pos) < 0.01 && Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) < 0.01 && Model.OurRobots[cutter2ID].Location.DistanceFrom(cutter2Pos) < 0.01)
                {
                    Counter2++;
                }
                if (Counter2 > 60)
                    CurrentState = (int)State.OneTouchMove;
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutter1ID].Location.DistanceFrom(cutter1Pos) < 0.01 && Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) < 1 && Model.OurRobots[cutter2ID].Location.DistanceFrom(cutter2Pos) < 0.01)
                {
                    CurrentState = (int)State.Cut;
                }
            }
            else if (CurrentState == (int)State.Cut)
            {
                Counter++;
                if (Counter > 300)
                    CurrentState = (int)State.Finish;
            }

            if (CurrentState == (int)State.First)
            {
                onetouchPos = otFirstPos;
                onetouchAngle = (GameParameters.OppGoalCenter - onetouchPos).AngleInDegrees;
                passerPos = Model.BallState.Location + (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6);
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                onetouchPos = passPos - (GameParameters.OppGoalCenter - passPos).GetNormalizeToCopy(0.1);
                onetouchAngle = (GameParameters.OppGoalCenter - onetouchPos).AngleInDegrees;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>(Model.OurRobots.Count);
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)State.First)
            {
                gotouch = false;
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutter1ID, new SingleObjectState(cutter1Pos, Vector2D.Zero, (float)cutter1Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutter2ID, new SingleObjectState(cutter1Pos, Vector2D.Zero, (float)cutter2Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.OneTouchMove)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutter1ID, new SingleObjectState(cutter1Pos, Vector2D.Zero, (float)cutter1Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutter2ID, new SingleObjectState(cutter1Pos, Vector2D.Zero, (float)cutter2Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.Cut)
            {
                bool gotopoint = true;
                if (Model.BallState.Speed.Size < 0.5 || Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) > 0.3)
                {
                    Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
                    gotopoint = false;
                }
                if (Model.BallState.Speed.Size >= 0.5)
                {
                    gotouch = true;
                }
                if (gotouch)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, onetouchID, typeof(OneTouchRole)))
                        Functions[onetouchID] = (eng, wmd) => GetRole<OneTouchRole>(onetouchID).Perform(eng, wmd, onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), null, false, GameParameters.OppGoalCenter, 7, false, gotopoint);
                }
                sync.Cut(engine, Model, passerID, Model.BallState.Location + new Vector2D(0.3, 0), passPos, false, 2.3, kickPowerType.Speed, 60, cutter1ID, GameParameters.OppGoalCenter, 100, false, kickPowerType.Power);
                if (Model.OurRobots[cutter1ID].Location.DistanceFrom(cutter1Pos) > 0.1)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, cutter2ID, typeof(CutBallRole)))
                        Functions[cutter2ID] = (eng, wmd) => GetRole<CutBallRole>(cutter2ID).CutIt(eng, wmd, cutter2ID, GameParameters.OppGoalCenter, 7, false);
                }
            }
            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }
        public enum State
        {
            First,
            OneTouchMove,
            Cut,
            Finish
        }
    }
}
