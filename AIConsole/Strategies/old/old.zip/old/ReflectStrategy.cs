﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.AIConsole.Roles;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.CommonClasses.MathLibrary;

namespace MRL.SSL.AIConsole.Strategies
{
    public class ReflectStrategy:StrategyBase
    {
        const double tresh = 0.05, angleTresh = 2, waitTresh = 20, finishTresh = 80, initDist = 0.22, maxWaitTresh = 360, passSpeedTresh = 0.07;

        double PasserAng, RotateTeta, KickPower, PassSpeed;
        Position2D PasserPos, ShootTarget, PassTarget;
        int[] PositionerIDs;
        double[] PositionerAng;
        Position2D[] PositionerPos;
        int PasserID;
        int counter, finishCounter, RotateDelay, timeLimitCounter, shooterIdx,rotateCounter;
        bool first, passed, inRot, firstInState, goPass, chip, chipOrigin;
       
        public override void ResetState()
        {
            PasserID = -1;
            first = true;
            passed = false;
            inRot = false;
            goPass = false;
            chip = false;
            chipOrigin = false;
            firstInState = true;
            PositionerIDs = new int[2];
            PositionerPos = new Position2D[2];
            PositionerAng = new double[2];
            PasserPos = Position2D.Zero;
            ShootTarget = Position2D.Zero;
            PassTarget = Position2D.Zero;
            PasserAng = 0;
            RotateTeta = 70;
            KickPower = 8;
            PassSpeed = 0;
            counter = 0;
            finishCounter = 0;
            RotateDelay = 30;
            rotateCounter = 2;
            shooterIdx = -1;
            timeLimitCounter = 0;
        }

        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.Start;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
        }

        public override void FillInformation()
        {
            StrategyName = "Reflect";
            AttendanceSize = 3;
            About = "this strategy attack opponents with 3 attacker!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            #region SET ID
            if (first)
            {
                if (!CalculateIDs(Model, Attendance.Keys.ToList(), ref PositionerIDs, ref PasserID))
                    return;
                first = false;
            }
            #endregion
            #region States
            if (CurrentState == (int)State.Start)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PasserID].Location.DistanceFrom(PasserPos) < tresh 
                    && Model.OurRobots[PositionerIDs[0]].Location.DistanceFrom(PositionerPos[0]) < 0.5
                    && Model.OurRobots[PositionerIDs[1]].Location.DistanceFrom(PositionerPos[1]) < 0.5)
                    counter++;
                if (counter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    timeLimitCounter = 0;
                    counter = 0;
                    firstInState = true;
                    CurrentState = (int)State.Go;
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (!passed && goPass)
                {
                    CurrentState = (int)State.Pass;
                    firstInState = true;
                }
                timeLimitCounter++;
                if (passed || timeLimitCounter > maxWaitTresh)
                    CurrentState = (int)State.Finish;
            }
            else if (CurrentState == (int)State.Pass)
            {
                timeLimitCounter++;
                if (passed)
                    finishCounter++;
                if (finishCounter > finishTresh || timeLimitCounter > maxWaitTresh)
                    CurrentState = (int)State.Finish;
            }
            #endregion 
            #region PosesAndAngles
            if (CurrentState == (int)State.Start)
            {
                if (firstInState)
                {
                    ShootTarget = GameParameters.OppGoalCenter;
                    PositionerPos[0] = GameParameters.OppGoalRight.Extend(+1.2, -.1);
                    PositionerPos[1] = GameParameters.OppGoalLeft.Extend(1.2, 0.1);
                    PositionerAng[0] = (ShootTarget - PositionerPos[0]).AngleInDegrees;
                    PositionerAng[1] = (ShootTarget - PositionerPos[1]).AngleInDegrees;
                    firstInState = false;
                }
                PasserPos = Model.BallState.Location + new Vector2D(initDist, 0);
                PasserAng = (ShootTarget - PasserPos).AngleInDegrees;
            }
            else if (CurrentState == (int)State.Go)
            {
                if (firstInState)
                {
                    int id0, id1;
                    CalcluateOppIds(engine, Model, PositionerIDs, out id0, out id1);

                    if (id0 != -1 && id1 != -1)
                        PassTarget = Position2D.Interpolate(Model.Opponents[id0].Location, Model.Opponents[id1].Location, ((Math.Sign(Model.BallState.Location.Y) >= 0)?1:0)).Extend(-RobotParameters.OurRobotParams.Diameter / 2, 0);// Model.Opponents[id0].Location + Vector2D.FromAngleSize(Math.PI, RobotParameters.OurRobotParams.Diameter / 2) + (Model.Opponents[id0].Location + Vector2D.FromAngleSize(Math.PI, RobotParameters.OurRobotParams.Diameter / 2) - Model.Opponents[id1].Location + Vector2D.FromAngleSize(Math.PI, RobotParameters.OurRobotParams.Diameter / 2)).GetNormalizeToCopy(Model.Opponents[id0].Location.DistanceFrom(Model.Opponents[id1].Location) / 2);
                    else if (id0 != -1)
                    {
                        PassTarget = CalculateReflectPoint(Model, ShootTarget, id0);
                    }
                    else if (id1 != -1)
                    {
                        PassTarget = CalculateReflectPoint(Model, ShootTarget, id1);
                    }
                    else
                        goPass = true;
                    PassSpeed = 7;
                    firstInState = false;
                }
                if (inRot && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
            }
            else if (CurrentState == (int)State.Pass)
            {
                if (firstInState)
                {
                    shooterIdx = 1;
                    if (PositionerPos[0].DistanceFrom(Model.BallState.Location) > PositionerPos[1].DistanceFrom(Model.BallState.Location))
                    {
                        shooterIdx = 0;
                    }
                    PassTarget = PositionerPos[shooterIdx] + (ShootTarget - PositionerPos[shooterIdx]).GetNormalizeToCopy(0.08);
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, chip, true);
                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;
                    firstInState = false;
                }
                if (inRot && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                chip = chipOrigin;
                if (!passed && !chipOrigin)
                {
                    Obstacles obs = new Obstacles(Model);
                    obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), null);
                    chip = obs.Meet(Model.BallState, new SingleObjectState(PassTarget, Vector2D.Zero, 0), 0.07);
                }
            }
            #endregion
        }
        private void CalcluateOppIds(GameStrategyEngine engine, WorldModel Model, int[] ids, out int id0, out int id1)
        {
            Line AtoOppGC = new Line(PositionerPos[0], GameParameters.OppGoalCenter);
            Line BtoOppGC = new Line(PositionerPos[1], GameParameters.OppGoalCenter);
            int minIdx0 = -1, minIdx1 = -1;
            double minDist0 = double.MaxValue, minDist1 = double.MaxValue;
            foreach (var item in Model.Opponents.Keys.ToList())
            {
                if (engine.GameInfo.OppTeam.GoaliID.HasValue && engine.GameInfo.OppTeam.GoaliID.Value == item)
                    continue;
                if (Model.Opponents[item].Location.DistanceFrom(GameParameters.OppGoalCenter) < Model.OurRobots[ids[0]].Location.DistanceFrom(GameParameters.OppGoalCenter))
                {
                    if (AtoOppGC.Distance(Model.Opponents[item].Location) < minDist0)
                    {
                        minDist0 = AtoOppGC.Distance(Model.Opponents[item].Location);
                        minIdx0 = item;
                    }
                }
                if (Model.Opponents[item].Location.DistanceFrom(GameParameters.OppGoalCenter) < Model.OurRobots[ids[1]].Location.DistanceFrom(GameParameters.OppGoalCenter))
                {
                    if (BtoOppGC.Distance(Model.Opponents[item].Location) < minDist1)
                    {
                        minDist1 = BtoOppGC.Distance(Model.Opponents[item].Location);
                        minIdx1 = item;
                    }
                }
            }
            id0 = minIdx0;
            id1 = minIdx1;
        }
        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId)
        {
            var tmpIds = attendIds.ToList();
            double minDist = double.MaxValue;
            int minIdx = -1;
            foreach (var item in tmpIds.ToList())
            {
                if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                {
                    minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                    minIdx = item;
                }
            }
            if (minIdx == -1)
                return false;
            passerId = minIdx;
            tmpIds.Remove(minIdx);
            for (int i = 0; i < 2; i++)
            {
                minDist = double.MaxValue;
                minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                ids[i] = minIdx;
                tmpIds.Remove(minIdx);
            }
            return true;
        }
        private Position2D CalculateReflectPoint(WorldModel model, Position2D target, int TargetRobotID)
        {
            List<Position2D> Ls_Robot2TargetPoints = new List<Position2D>();
            List<Position2D> Ls_Ball2TargetPoints = new List<Position2D>();
            Line Ln_balltoRobot = new Line(model.BallState.Location, model.Opponents[TargetRobotID].Location);
            Line Ln_TargettoRobot = new Line(target, model.Opponents[TargetRobotID].Location);
            Vector2D Vec_Targettorobot = Ln_TargettoRobot.Head - Ln_TargettoRobot.Tail;
            Vector2D firstfromtarget = Vector2D.FromAngleSize(Vec_Targettorobot.AngleInRadians + (Math.PI / 2), .09);
            Ls_Robot2TargetPoints.Add(model.Opponents[TargetRobotID].Location + firstfromtarget);
            Vector2D Secondfromtarget = Vector2D.FromAngleSize(Vec_Targettorobot.AngleInRadians - (Math.PI / 2), .09);
            Ls_Robot2TargetPoints.Add(model.Opponents[TargetRobotID].Location + Secondfromtarget);

            Vector2D Vec_balltorobot = Ln_balltoRobot.Head - Ln_balltoRobot.Tail;
            Vector2D firstfromBall = Vector2D.FromAngleSize(Vec_balltorobot.AngleInRadians + (Math.PI / 2), .09);
            Ls_Ball2TargetPoints.Add(model.Opponents[TargetRobotID].Location + firstfromBall);
            Vector2D Secondfromball = Vector2D.FromAngleSize(Vec_balltorobot.AngleInRadians - (Math.PI / 2), .09);
            Ls_Ball2TargetPoints.Add(model.Opponents[TargetRobotID].Location + Secondfromball);
            double mindist = double.MaxValue;
            Position2D bestposfromball = Position2D.Zero;
            foreach (var item in Ls_Ball2TargetPoints)
            {
                if (item.DistanceFrom(target) < mindist)
                {
                    mindist = item.DistanceFrom(target);
                    bestposfromball = item;
                }
            }
            mindist = double.MaxValue;
            Position2D bestposfromtarget = Position2D.Zero;
            foreach (var item in Ls_Robot2TargetPoints)
            {
                if (item.DistanceFrom(model.BallState.Location) < mindist)
                {
                    mindist = item.DistanceFrom(model.BallState.Location);
                    bestposfromtarget = item;
                }
            }
            Line line1 = new Line(model.BallState.Location, bestposfromball);
            Line line2 = new Line(target, bestposfromtarget);
            Position2D? intersect = line1.IntersectWithLine(line2);
            Position2D Target = Position2D.Zero;
            if (intersect.HasValue)
            {
                Vector2D intersecttorobot = intersect.Value - model.Opponents[TargetRobotID].Location;
                Vector2D Normalizeintersecttorobot = Vector2D.FromAngleSize(intersecttorobot.AngleInRadians, 0.09);
                Target = model.Opponents[TargetRobotID].Location + Normalizeintersecttorobot;
            }
            return Target;
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.Start)
            {
                Planner.Add(PositionerIDs[0], PositionerPos[0], PositionerAng[0], PathType.UnSafe, true, true, true, true);
                Planner.Add(PositionerIDs[1], PositionerPos[1], PositionerAng[1], PathType.UnSafe, true, true, true, true);
                Planner.ChangeDefaulteParams(PasserID, false);
                Planner.SetParameter(PasserID, 3, 2.5);
                Planner.Add(PasserID, PasserPos, PasserID, PathType.UnSafe, true, true, true, true);

            }
            else if (CurrentState == (int)State.Go)
            {
               
                Planner.Add(PositionerIDs[0], PositionerPos[0], PositionerAng[0], PathType.UnSafe, false, false, true, !passed);
                Planner.Add(PositionerIDs[1], PositionerPos[1], PositionerAng[1], PathType.UnSafe, false, false, true, !passed);
               
                if (Planner.AddRotate(Model, PasserID, PassTarget, RotateTeta, kickPowerType.Speed, PassSpeed, false, Math.Max(RotateDelay, rotateCounter), true).IsInRotateDelay)
                {
                    inRot = true;
                }
            }
            else if (CurrentState == (int)State.Pass)
            {
                for (int i = 0; i < 2; i++)
                {
                    if (i != shooterIdx)
                        Planner.Add(PositionerIDs[i], PositionerPos[i], PositionerAng[i], PathType.UnSafe, false, false, true, !passed);
                    else
                    {
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionerIDs[shooterIdx], typeof(OneTouchRole)))
                            Functions[PositionerIDs[shooterIdx]] = (eng, wmd) => GetRole<OneTouchRole>(PositionerIDs[shooterIdx]).Perform(engine, Model, PositionerIDs[shooterIdx], Model.OurRobots[PasserID], chip, ShootTarget, KickPower, false, PassSpeed);
                    }
                }
                if (Planner.AddRotate(Model, PasserID, PassTarget, RotateTeta, kickPowerType.Speed, PassSpeed, chip, Math.Max(RotateDelay, rotateCounter), true).IsInRotateDelay)
                {
                    inRot = true;
                }
            }
            return CurrentlyAssignedRoles;
        }
 
        public enum State
        {
            Start,
            Go,
            Pass,
            Finish
        }

    }
}
