﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    class ChipPassStrategy : StrategyBase
    {
        public override void ResetState()
        {
            CurrentState = InitialState;
            first = true;
            isInint = false;
            Counter = 0;
            targetchanged = false;
            
            pos2pass = new Position2D(-1.5, 1.5);
            pos1 = new Position2D(0.2, 1.8);
            pos2 = new Position2D(0.2, -1.8);
            posActive = new Position2D(1.5, 1);
        }

        bool first = true;
        int passerID = 0;
        int positioner1ID = 0;
        int positioner2ID = 0;
        int activeID = 0;
        Position2D pos2pass = new Position2D(-1.5, 1.5);
        Position2D pos1 = new Position2D(0.2, 1.8);
        Position2D pos2 = new Position2D(0.2, -1.8);
        Position2D posActive = new Position2D(1.5, 1);
        Position2D posPasser = new Position2D();

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = 0;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }
        Position2D[] pos = new Position2D[2];
        int Counter = 0;
        bool targetchanged = false;
        public override void FillInformation()
        {
            StrategyName = "ChipPass KickOff";
            AttendanceSize = 4;
            About = "this strategy run in kickoff";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)states.finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            if (first)
            {
                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && pos1.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = pos1.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                positioner1ID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && item.Key != positioner1ID && pos2.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = pos2.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                positioner2ID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w != positioner1ID && w != positioner2ID).ToList();
                if (list.Count > 0)
                    activeID = list[0];
                posPasser = Model.BallState.Location + new Vector2D(0.13, 0);
                first = false;
            }

            if (CurrentState == (int)states.waiting)
            {
                if (Model.Status == GameStatus.KickOff_OurTeam_Go)
                    CurrentState = (int)states.firstPositionning;
            }
            else if (CurrentState == (int)states.firstPositionning)
            {
                if (Model.OurRobots[passerID].Location.DistanceFrom(posPasser) < 0.01 && Model.OurRobots[positioner1ID].Location.DistanceFrom(pos1) < 0.01 && Model.OurRobots[positioner2ID].Location.DistanceFrom(pos2) < 0.01 && Model.OurRobots[activeID].Location.DistanceFrom(posActive) < 0.01)
                    Counter++;
                if (Counter > 30)
                    CurrentState = (int)states.Move;
            }
            else if (CurrentState == (int)states.Move)
            {
                if (Model.BallState.Location.DistanceFrom(Model.OurRobots[activeID].Location) < 0.3)
                    CurrentState = (int)states.finish;
            }
            if (CurrentState == (int)states.Move)
            {
                if (Model.BallState.Speed.Size > 0.5)
                    targetchanged = true;
                if (targetchanged)
                    pos2pass = Model.BallState.Location;
                if (Model.OurRobots[activeID].Location.X < 0)
                    pos1 = posActive;
            }

        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>(Model.OurRobots.Count);
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)states.waiting)
            {

                Planner.Add(passerID, Model.BallState.Location + (Model.BallState.Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.6), (Model.BallState.Location - Model.OurRobots[passerID].Location).AngleInDegrees);
                Position2D targ1 = Model.BallState.Location + Vector2D.FromAngleSize((GameParameters.OurGoalCenter - Model.BallState.Location).AngleInRadians + 0.66, 0.6);
                Planner.Add(positioner1ID, targ1, (Model.BallState.Location - Model.OurRobots[positioner1ID].Location).AngleInDegrees);
                Position2D targ2 = Model.BallState.Location + Vector2D.FromAngleSize((GameParameters.OurGoalCenter - Model.BallState.Location).AngleInRadians - 0.66, 0.6);
                Planner.Add(positioner2ID, targ2, (Model.BallState.Location - Model.OurRobots[positioner2ID].Location).AngleInDegrees);
                Planner.Add(activeID, Model.BallState.Location + (Model.BallState.Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.9), (GameParameters.OppGoalCenter - Model.BallState.Location).AngleInDegrees);
            }
            else if (CurrentState == (int)states.firstPositionning)
            {
                posPasser = Model.BallState.Location + (Model.BallState.Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.6);
                Planner.Add(passerID, posPasser, (Model.BallState.Location - Model.OurRobots[passerID].Location).AngleInDegrees);
                Planner.Add(positioner1ID, pos1, (Model.BallState.Location - Model.OurRobots[positioner1ID].Location).AngleInDegrees);
                Planner.Add(positioner2ID, pos2, (Model.BallState.Location - Model.OurRobots[positioner2ID].Location).AngleInDegrees);
                Planner.Add(activeID, posActive, (GameParameters.OppGoalCenter - Model.BallState.Location).AngleInDegrees);
            }
            else if (CurrentState == (int)states.Move)
            {
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, passerID, typeof(PenaltyShooterRole)))
                    Functions[passerID] = (eng, wmd) => GetRole<PenaltyShooterRole>(passerID).Perform(engine, Model, passerID, 150, CurrentlyAssignedRoles);

                Planner.Add(positioner1ID, pos1, (Model.BallState.Location - Model.OurRobots[positioner1ID].Location).AngleInDegrees);
                Planner.Add(positioner2ID, pos2, (Model.BallState.Location - Model.OurRobots[positioner2ID].Location).AngleInDegrees);
                Planner.Add(activeID, pos2pass, (GameParameters.OppGoalCenter - Model.BallState.Location).AngleInDegrees);
            }

            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }

        enum states
        {
            waiting,
            firstPositionning,
            Move,
            finish
        }
    }
}
