﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.AIConsole.Roles;
using MRL.SSL.Planning.MotionPlanner;

namespace MRL.SSL.AIConsole.Strategies
{
    public class DirectKickOffStrategy:StrategyBase
    {
        public override void ResetState()
        {
            isInint = false;
            CurrentState = InitialState;
            timer = 0;
            
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)state.FirstPositioning;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }
        int shooterID, positioner1ID, positioner2ID;
        int timer = 0;
        Position2D[] firstPos = new Position2D[3];
        Position2D[] seccondtPos = new Position2D[3];


        public override void FillInformation()
        {
            StrategyName = "direct kickoff";
            AttendanceSize = 3;
            About = "a strategy for direct kickoff";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)state.finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            SingleObjectState shooterPos = new SingleObjectState();
            SingleObjectState positioner1Pos = new SingleObjectState();
            SingleObjectState positioner2Pos = new SingleObjectState();
            double nearDist = 0.1;
            if (CurrentState == (int)state.FirstPositioning)
            {
                firstPos[0] = Model.BallState.Location.Extend(0.6, 0);
                firstPos[1] = Model.BallState.Location + Vector2D.FromAngleSize(0.7, 0.6);
                firstPos[2] = Model.BallState.Location + Vector2D.FromAngleSize(-0.7, 0.6);

                List<int> ids = Attendance.Keys.ToList();
                ids.ToList().Sort();
                shooterID = ids[0];
                positioner1ID = ids[1];
                positioner2ID = ids[2];

                shooterPos = Model.OurRobots[shooterID];
                positioner1Pos = Model.OurRobots[positioner1ID];
                positioner2Pos = Model.OurRobots[positioner2ID];

                if (shooterPos.Location.DistanceFrom(firstPos[0]) < nearDist &&
                   positioner1Pos.Location.DistanceFrom(firstPos[1]) < nearDist &&
                   positioner2Pos.Location.DistanceFrom(firstPos[2]) < nearDist
                    && Model.Status == GameStatus.KickOff_OurTeam_Go)
                {
                    CurrentState = (int)state.BackBall;
                }
            }
            else if (CurrentState == (int)state.BackBall)
            {
                firstPos[0] = Model.BallState.Location + (Model.BallState.Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.095);
                firstPos[1] = new Position2D(0.2, 1.9);
                firstPos[2] = new Position2D(0.2, -1.9);

                timer++;
                if (timer > 200)
                    CurrentState = (int)state.Shoot;
            }
            else if (CurrentState == (int)state.Shoot)
            {
                firstPos[0] = Model.BallState.Location + (Model.BallState.Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.095);
                if (Model.BallState.Location.DistanceFrom(Model.OurRobots[shooterID].Location) > 1)
                    CurrentState = 4;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)state.FirstPositioning)
            {
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, shooterID, typeof(GotoPointRole)))
                    Functions[shooterID] = (eng, wmd) => GetRole<GotoPointRole>(shooterID).GotoPoint(Model, shooterID, firstPos[0], (Model.BallState.Location - Model.OurRobots[shooterID].Location).AngleInDegrees, true, true);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner1ID, typeof(GotoPointRole)))
                    Functions[positioner1ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner1ID).GotoPoint(Model, positioner1ID, firstPos[1], (Model.BallState.Location - Model.OurRobots[positioner1ID].Location).AngleInDegrees, true, true);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner2ID, typeof(GotoPointRole)))
                    Functions[positioner2ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner2ID).GotoPoint(Model, positioner2ID, firstPos[2], (Model.BallState.Location - Model.OurRobots[positioner2ID].Location).AngleInDegrees, true, true);
            }
            else if (CurrentState == (int)state.BackBall)
            {
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, shooterID, typeof(GotoPointRole)))
                    Functions[shooterID] = (eng, wmd) => GetRole<GotoPointRole>(shooterID).GotoPoint(Model, shooterID, firstPos[0], (Model.BallState.Location - Model.OurRobots[shooterID].Location).AngleInDegrees, true, false);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner1ID, typeof(GotoPointRole)))
                    Functions[positioner1ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner1ID).GotoPoint(Model, positioner1ID, firstPos[1], (GameParameters.OppGoalCenter - Model.OurRobots[positioner1ID].Location).AngleInDegrees, true, true);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner2ID, typeof(GotoPointRole)))
                    Functions[positioner2ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner2ID).GotoPoint(Model, positioner2ID, firstPos[2], (GameParameters.OppGoalCenter - Model.OurRobots[positioner2ID].Location).AngleInDegrees, true, true);
            }
            else if (CurrentState == (int)state.Shoot)
            {
                Obstacles obs = new Obstacles(Model);
                obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), (engine.GameInfo.OppTeam.GoaliID.HasValue) ? new List<int>() { engine.GameInfo.OppTeam.GoaliID.Value } : null);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, shooterID, typeof(GotoPointRole)))
                    //if (MeetObtacles.MeetsObstacles(Model, shooterID, Model.BallState.Location, GameParameters.OppGoalCenter, false, true, false, false))
                    //{
                    Functions[shooterID] = (eng, wmd) => GetRole<GotoPointRole>(shooterID).GotoPoint(eng, Model, shooterID, firstPos[0], (Model.BallState.Location - Model.OurRobots[shooterID].Location).AngleInDegrees, true, true, false, true, 2, 2);
                if (obs.Meet(Model.BallState, new SingleObjectState(GameParameters.OppGoalCenter, Vector2D.Zero, 0), 0.15))
                    Planner.AddKick(shooterID, kickPowerType.Speed, 2, true, false);
                else
                    Planner.AddKick(shooterID, kickPowerType.Speed, 7, false, false);
                //}
                //else
                //    Functions[shooterID] = (eng, wmd) => GetRole<GotoPointRole>(shooterID).GotoPoint(eng, Model, shooterID, firstPos[0], (Model.BallState.Location - Model.OurRobots[shooterID].Location).AngleInDegrees, true, true, false, false, 7, 2);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner1ID, typeof(GotoPointRole)))
                    Functions[positioner1ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner1ID).GotoPoint(Model, positioner1ID, firstPos[1], (GameParameters.OppGoalCenter - Model.OurRobots[positioner1ID].Location).AngleInDegrees, true, true);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positioner2ID, typeof(GotoPointRole)))
                    Functions[positioner2ID] = (eng, wmd) => GetRole<GotoPointRole>(positioner2ID).GotoPoint(Model, positioner2ID, firstPos[2], (GameParameters.OppGoalCenter - Model.OurRobots[positioner2ID].Location).AngleInDegrees, true, true);
            }

            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }

        enum state
        {
            FirstPositioning = 0,
            BackBall = 1,
            Shoot = 2,
            finish = 3
        }
    }
}
