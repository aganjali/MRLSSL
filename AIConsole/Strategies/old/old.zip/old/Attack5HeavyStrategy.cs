﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.GameDefinitions;
using MRL.SSL.AIConsole.Roles;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.Planning.GamePlanner.Types;

namespace MRL.SSL.AIConsole.Strategies
{
    class Attack5HeavyStrategy:StrategyBase
    {
        const double tresh = 0.05, stuckTresh = 0.23, angleTresh = 2, waitTresh = 50, finishTresh = 100, initDist = 0.22, maxWaitTresh = 180, passSpeedTresh = 0.08, behindBallTresh = 0.07, fieldMargin = 0.12;

        bool first, firstInState, isChip, chipOrigin, changeShooter, shooterFirstMove, passed, goActive, inRotate, goBack;
        int[] PositionersID;
        int PasserID, ShooterIdx, DefenderID, initialPosCounter, finishCounter, timeLimitCounter, RotateDelay, rotateCounter;
        Position2D PasserPos, ShooterPos, DefenderPos, GoaliePos, ShootTarget, PassTarget;
        Position2D[] PositionersPos;
        double PasserAng, ShooterAng, DefenderAng, GoalieAng, PassSpeed, KickSpeed, RotateTeta;
        double[] PositionersAng;
        Syncronizer sync;

        public override void ResetState()
        {
            PositionersID = new int[3];
            PositionersAng = new double[3];
            PositionersPos = new Position2D[3];

            PasserID = -1;
            ShooterIdx = -1;
            DefenderID = -1;

            PasserAng = 0;
            ShooterAng = 0;
            DefenderAng = 0;
            GoalieAng = 0;

            PassSpeed = 0;
            KickSpeed = 8;
            initialPosCounter = 0;
            finishCounter = 0;
            timeLimitCounter = 0;
            RotateDelay = 60;
            RotateTeta = 90;
            rotateCounter = 2;

            PasserPos = Position2D.Zero;
            ShooterPos = Position2D.Zero;
            DefenderPos = Position2D.Zero;
            GoaliePos = Position2D.Zero;
            ShootTarget = Position2D.Zero;
            PassTarget = Position2D.Zero;

            chipOrigin = false;
            isChip = false;
            changeShooter = false;
            firstInState = true;
            shooterFirstMove = false;
            passed = false;
            goActive = false;
            inRotate = false;
            goBack = false;
            if (sync != null)
                sync.Reset();
            else
                sync = new Syncronizer();
            first = true;
        }

        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId, ref int defenderId)
        {
            var tmpIds = attendIds.Where(w => (!Model.GoalieID.HasValue || w != Model.GoalieID.Value)).ToList();
            int[] allIds = new int[4];
            double maxDist = double.MinValue;
            int maxIdx = -1;
            foreach (var item in tmpIds)
            {
                if (Model.OurRobots.ContainsKey(item) && Model.OurRobots[item].Location.X > maxDist)
                {
                    maxDist = Model.OurRobots[item].Location.X;
                    maxIdx = item;
                }
            }
            if (maxIdx == -1)
                return false;
            defenderId = maxIdx;
            tmpIds.Remove(maxIdx);
            for (int i = 0; i < 4; i++)
            {
                double minDist = double.MaxValue;
                int minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                allIds[i] = minIdx;
                tmpIds.Remove(allIds[i]);
            }
            passerId  = allIds[0];
            PositionersID[0] = allIds[1];
            PositionersID[1] = allIds[2];
            PositionersID[2] = allIds[3];
            return true;
        }
        private void CalculateDefenderInfo(GameStrategyEngine engine, WorldModel Model, out Position2D defPos, out Position2D goalipos, out double defAng, out double goaliang)
        {
            List<DefenderCommand> defendcommands = new List<DefenderCommand>();
            int? id = null;
            defendcommands.Add(new DefenderCommand()
            {
                RoleType = typeof(GoalieCornerRole)
            });
            defendcommands.Add(new DefenderCommand()
            {
                RoleType = typeof(DefenderCornerRole1),
                OppID = engine.GameInfo.OppTeam.Scores.Count > 0 ? engine.GameInfo.OppTeam.Scores.ElementAt(0).Key : id
            });
            var infos = FreekickDefence.Match(engine, Model, defendcommands);
            var gol = infos.SingleOrDefault(s => s.RoleType == typeof(GoalieCornerRole));
            var normal1 = infos.SingleOrDefault(s => s.RoleType == typeof(DefenderCornerRole1));
            goalipos = (gol.DefenderPosition.HasValue) ? gol.DefenderPosition.Value : Position2D.Zero;
            goaliang = gol.Teta;
            defPos = (normal1.DefenderPosition.HasValue) ? normal1.DefenderPosition.Value : Position2D.Zero;
            defAng = normal1.Teta;
        }
        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.InitialState;
            InitialState = 0;
            FinalState = 4;
            TrapState = 4;
        }

        public override void FillInformation()
        {
            StrategyName = "HeavyAttack5";
            AttendanceSize = 6;
            About = "this strategy will attack opp team with 5 attend heavily";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            #region First
            if (first)
            {
                if (!CalculateIDs(Model, Attendance.Keys.ToList(), ref PositionersID, ref PasserID, ref DefenderID))
                    return;
                first = false;
            }
            #endregion
            #region States
            if (CurrentState == (int)State.InitialState)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PasserID].Location.DistanceFrom(PasserPos) < tresh
                    && Model.OurRobots[PositionersID[0]].Location.DistanceFrom(PositionersPos[0]) < stuckTresh
                    && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(PositionersPos[1]) < stuckTresh
                    && Model.OurRobots[DefenderID].Location.DistanceFrom(DefenderPos) < tresh
                    && (!Model.GoalieID.HasValue || !Model.OurRobots.ContainsKey(Model.GoalieID.Value) || (Model.OurRobots[Model.GoalieID.Value].Location.DistanceFrom(GoaliePos) < tresh)))
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    Obstacles obs = new Obstacles(Model);
                    obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), ((engine.GameInfo.OppTeam.GoaliID.HasValue) ? new List<int>() { engine.GameInfo.OppTeam.GoaliID.Value } : null));
                    if (!obs.Meet(Model.OurRobots[PositionersID[0]], new SingleObjectState(GameParameters.OppGoalCenter, Vector2D.Zero, 0), 0.15))
                    {
                        CurrentState = (int)State.Rush2Hole;
                        ShooterIdx = 0;
                    }
                    else if (!obs.Meet(Model.OurRobots[PositionersID[1]], new SingleObjectState(GameParameters.OppGoalCenter, Vector2D.Zero, 0), 0.15))
                    {
                        CurrentState = (int)State.OneTouch;
                        ShooterIdx = 1;
                    }
                    else if (!obs.Meet(Model.OurRobots[PositionersID[2]], new SingleObjectState(GameParameters.OppGoalCenter, Vector2D.Zero, 0), 0.15))
                    {
                        CurrentState = (int)State.OneTouch;
                        ShooterIdx = 2;
                    }
                    else
                    {
                        CurrentState = (int)State.Heavy;
                    }
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.Heavy)
            {
                if (Model.OurRobots[DefenderID].Location.X < 0 || passed)
                {
                    goBack = true;
                }
                if (passed)
                    finishCounter++;
                if (sync.Finished || sync.Failed || finishCounter > finishTresh)
                    CurrentState = (int)State.Finish;
            }
            else if (CurrentState == (int)State.Rush2Hole)
            {
                if (passed)
                    finishCounter++;
                if (sync.Finished || sync.Failed || finishCounter > finishTresh)
                    CurrentState = (int)State.Finish;
            }
            else if (CurrentState == (int)State.OneTouch)
            {
                if (passed)
                    finishCounter++;
                if (sync.Finished || sync.Failed || finishCounter > finishTresh)
                    CurrentState = (int)State.Finish;
            }
            #endregion
            #region DefendersInfo
            CalculateDefenderInfo(engine, Model, out DefenderPos, out GoaliePos, out DefenderAng, out GoalieAng);
            #endregion
            #region PosAndAngles
            if (CurrentState == (int)State.InitialState)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                //PassTarget = new Position2D(-1.5, Math.Sign(Model.BallState.Location.Y) * 1);
                PasserPos = Model.BallState.Location + (Model.BallState.Location - ShootTarget).GetNormalizeToCopy(initDist);
                PasserAng = (Model.BallState.Location - PasserPos).AngleInDegrees;

                //ShooterPos = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(behindBallTresh);
                //ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;
                double sgn = Math.Sign(Model.BallState.Location.Y);
                Position2D p0 = new Position2D(-2.4, sgn * 0.67);
                double r = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), 0.6);

                PositionersPos[0] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                PositionersAng[0] = (ShootTarget - PositionersPos[0]).AngleInDegrees;

                p0 = new Position2D(-2.4, -sgn * 0.67);
                r = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), 0.25);

                PositionersPos[1] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;

                PositionersPos[1] = new Position2D(-1.8, -Math.Sign(Model.BallState.Location.Y)*0.5);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;

                p0 = new Position2D(-2.57, -sgn * 0.95);
                r = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), 0.25);

                PositionersPos[2] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                PositionersAng[2] = (ShootTarget - PositionersPos[2]).AngleInDegrees;

            }
            else if (CurrentState == (int)State.Rush2Hole)
            {
                if (firstInState)
                {
                    PassTarget = GameParameters.OppGoalCenter + (Model.OurRobots[PositionersID[ShooterIdx]].Location - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.6);
                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;
                    ShooterAng = (ShootTarget - PassTarget).AngleInDegrees;
                    PasserPos = PositionersPos[ShooterIdx];
                    PasserAng = PositionersAng[ShooterIdx];
                    isChip = true;
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, isChip, true);

                    firstInState = false;
                }
                if (inRotate && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                double dist, DistFromBorder;
                if (passed && GameParameters.IsInDangerousZone(Model.BallState.Location, true, 0, out dist, out DistFromBorder))
                    goActive = true;
            }
            else if (CurrentState == (int)State.OneTouch)
            {
                if (firstInState)
                {
                    PassTarget = Model.OurRobots[PositionersID[ShooterIdx]].Location + (ShootTarget - Model.OurRobots[PositionersID[ShooterIdx]].Location).GetNormalizeToCopy(behindBallTresh);
                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;
                    PasserPos = GameParameters.OppGoalCenter + (PasserPos - GameParameters.OppGoalCenter).GetNormalizeToCopy(0.8);
                    PasserAng = (ShootTarget - PasserPos).AngleInDegrees;
                    firstInState = false;
                }
                if (inRotate && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                if (!passed)
                {
                    isChip = chipOrigin;
                    if (!chipOrigin)
                    {
                        Obstacles obs = new Obstacles(Model);
                        obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), null);
                        isChip = obs.Meet(Model.BallState, new SingleObjectState(PassTarget, Vector2D.Zero, 0), 0.07);
                    }
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, isChip, true);
                    if (isChip && PassTarget.X > -1.9)
                        PassSpeed = 0.9;
                }
            }
            else if (CurrentState == (int)State.Heavy)
            {
                if (firstInState)
                {
                    double r = GameParameters.SafeRadi(new SingleObjectState(-PositionersPos[0], Vector2D.Zero, 0), 0.12);

                    PositionersPos[0] = GameParameters.OppGoalCenter + (PositionersPos[0] - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                    PositionersAng[0] = (ShootTarget - PositionersPos[0]).AngleInDegrees;

                    r = GameParameters.SafeRadi(new SingleObjectState(-PositionersPos[1], Vector2D.Zero, 0), 0.12);
                    PositionersPos[1] = GameParameters.OppGoalCenter + (PositionersPos[1] - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                    PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;

                    r = GameParameters.SafeRadi(new SingleObjectState(-PositionersPos[2], Vector2D.Zero, 0), 0.12);
                    PositionersPos[2] = GameParameters.OppGoalCenter + (PositionersPos[2] - GameParameters.OppGoalCenter).GetNormalizeToCopy(r);
                    PositionersAng[2] = (ShootTarget - PositionersPos[2]).AngleInDegrees;

                    double width = 0.6, heigth = 0.6, step = 0.2;
                    Position2D topLeft = new Position2D(Math.Min(Model.BallState.Location.X + 2, 0.5), ((Math.Sign(Model.BallState.Location.Y) >= 0) ? -0.66 : 0));

                    Position2D bestPoint = Position2D.Zero;
                    isChip = chipOrigin;
                    engine.GameInfo.BestPassPoint(Model, ShootTarget, topLeft, width, heigth, (int)(width / step), (int)(heigth / step), ref isChip, ref bestPoint);
                    chipOrigin = isChip;
                    PassTarget = bestPoint;
                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;
                    firstInState = false;
                }
                if (inRotate && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                if (!passed)
                {
                    isChip = chipOrigin;
                    if (!chipOrigin)
                    {
                        Obstacles obs = new Obstacles(Model);
                        obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), null);
                        isChip = obs.Meet(Model.BallState, new SingleObjectState(PassTarget, Vector2D.Zero, 0), 0.07);
                    }
                    PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, isChip, true);
                    if (isChip && PassTarget.X > -1.9)
                        PassSpeed = 0.9;
                }
            }
            #endregion
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.InitialState)
            {
                Planner.ChangeDefaulteParams(PasserID, false);
                Planner.SetParameter(PasserID, 2.5, 2);
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, true, true, true, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.ChangeDefaulteParams(PositionersID[i], false);
                    Planner.SetParameter(PositionersID[i], 3, 2.5);
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, DefenderID, typeof(DefenderCornerRole1)))
                    Functions[DefenderID] = (eng, wmd) => GetRole<DefenderCornerRole1>(DefenderID).Run(engine, Model, DefenderID, DefenderPos, DefenderAng);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, Model.GoalieID, typeof(GoalieCornerRole)))
                    Functions[Model.GoalieID.Value] = (eng, wmd) => GetRole<GoalieCornerRole>(Model.GoalieID.Value).Run(engine, Model, Model.GoalieID.Value, GoaliePos, GoalieAng);
            }
            else if (CurrentState == (int)State.Rush2Hole)
            {
                if (!passed)
                {
                    if (Planner.AddRotate(Model, PasserID, PassTarget, RotateTeta, kickPowerType.Speed, PassSpeed, isChip, RotateDelay, false).IsInRotateDelay)
                        inRotate = true;
                    
                    for (int i = 0; i < PositionersPos.Length; i++)
                        Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
                else
                {
                    Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, false, false, false, false);
                    if (!goActive)
                        Planner.Add(PositionersID[ShooterIdx], PassTarget, ShooterAng, PathType.UnSafe, false, false, false, false);
                    else
                    {
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[ShooterIdx], typeof(ActiveRole)))
                            Functions[PositionersID[ShooterIdx]] = (eng, wmd) => GetRole<ActiveRole>(PositionersID[ShooterIdx]).Perform(engine, Model, PositionersID[ShooterIdx], PasserID);
                    }
                    for (int i = 0; i < PositionersPos.Length; i++)
                    {
                        if (i == ShooterIdx)
                            continue;
                        Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, false);
                    }
                }
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, DefenderID, typeof(DefenderCornerRole1)))
                    Functions[DefenderID] = (eng, wmd) => GetRole<DefenderCornerRole1>(DefenderID).Run(engine, Model, DefenderID, DefenderPos, DefenderAng);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, Model.GoalieID, typeof(GoalieCornerRole)))
                    Functions[Model.GoalieID.Value] = (eng, wmd) => GetRole<GoalieCornerRole>(Model.GoalieID.Value).Run(engine, Model, Model.GoalieID.Value, GoaliePos, GoalieAng);
            }
            else if (CurrentState == (int)State.OneTouch)
            {
                if (!passed)
                {
                    if (Planner.AddRotate(Model, PasserID, PassTarget, RotateTeta, kickPowerType.Speed, PassSpeed, isChip, RotateDelay, false).IsInRotateDelay)
                        inRotate = true;

                    for (int i = 0; i < PositionersPos.Length; i++)
                        Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
                else
                {
                    Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, false, false, false, false);
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[ShooterIdx], typeof(OneTouchRole)))
                        Functions[PositionersID[ShooterIdx]] = (eng, wmd) => GetRole<OneTouchRole>(PositionersID[ShooterIdx]).Perform(engine, Model, PositionersID[ShooterIdx], Model.OurRobots[PasserID], isChip, ShootTarget, KickSpeed, false, PassSpeed);
                    for (int i = 0; i < PositionersPos.Length; i++)
                    {
                        if (i == ShooterIdx)
                            continue;
                        Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, false);
                    }
                }
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, DefenderID, typeof(DefenderCornerRole1)))
                    Functions[DefenderID] = (eng, wmd) => GetRole<DefenderCornerRole1>(DefenderID).Run(engine, Model, DefenderID, DefenderPos, DefenderAng);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, Model.GoalieID, typeof(GoalieCornerRole)))
                    Functions[Model.GoalieID.Value] = (eng, wmd) => GetRole<GoalieCornerRole>(Model.GoalieID.Value).Run(engine, Model, Model.GoalieID.Value, GoaliePos, GoalieAng);
            }
            else if (CurrentState == (int)State.Heavy)
            {
                if (isChip)
                    sync.SyncChipPass(engine, Model, PasserID, RotateTeta, DefenderID, PassTarget, ShootTarget, PassSpeed, KickSpeed, RotateDelay);
                else
                    sync.SyncDirectPass(engine, Model, PasserID, RotateTeta, DefenderID, PassTarget, ShootTarget, PassSpeed, KickSpeed, RotateDelay);
                inRotate = sync.InRotate;
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    if (goBack && i == 1)
                        continue;
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, false);
                }
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, Model.GoalieID, typeof(GoalieCornerRole)))
                    Functions[Model.GoalieID.Value] = (eng, wmd) => GetRole<GoalieCornerRole>(Model.GoalieID.Value).Run(engine, Model, Model.GoalieID.Value, GoaliePos, GoalieAng);
                if (goBack)
                {
                    if (Model.OurRobots[PositionersID[1]].Location.DistanceFrom(DefenderPos) > 1)
                        Planner.Add(PositionersID[1], DefenderPos, DefenderAng, PathType.UnSafe, false, true, true, true);
                    else
                    {
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[1], typeof(DefenderCornerRole1)))
                            Functions[PositionersID[1]] = (eng, wmd) => GetRole<DefenderCornerRole1>(PositionersID[1]).Run(engine, Model, PositionersID[1], DefenderPos, DefenderAng);
                    }
                }
            }
            return CurrentlyAssignedRoles;
        }
        enum State
        {
            InitialState,
            Rush2Hole,
            OneTouch,
            Heavy,
            Finish
        }
    }
}
