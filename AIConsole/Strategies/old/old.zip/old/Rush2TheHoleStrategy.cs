﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.AIConsole.Roles;
using MRL.SSL.Planning.MotionPlanner;

namespace MRL.SSL.AIConsole.Strategies
{
    public class Rush2TheHoleStrategy:StrategyBase
    {
        const double tresh = 0.05, stuckTresh = 0.23, angleTresh = 2, waitTresh = 20, finishTresh = 180, initDist = 0.22, maxWaitTresh = 180, passSpeedTresh = 0.08, behindBallTresh = 0.07;

        bool first, firstInState, isChip, chipOrigin;
        
        int[] PositionersID;
        int PasserID, ShooterID, initialPosCounter, finishCounter, timeLimitCounter, RotateDelay;
        Position2D PasserPos, ShooterPos, ShootTarget, PassTarget;
        Position2D[] PositionersPos;
        double PasserAng, ShooterAng, PassSpeed, KickSpeed, firstPassSpeed, secondPassSpeed;
        double[] PositionersAng;

        public override void ResetState()
        {
            int posCount =Math.Max(AttendanceSize - 2,0);
            PositionersID = new int[posCount];
            PositionersAng = new double[posCount];
            PositionersPos = new Position2D[posCount];
            PasserID = -1;
            ShooterID = -1;
            PasserAng = 0;
            ShooterAng = 0;
            PassSpeed = 0;
            firstPassSpeed = 2;
            secondPassSpeed = 2;
            KickSpeed = 8;
            initialPosCounter = 0;
            finishCounter = 0;
            timeLimitCounter = 0;
            RotateDelay = 30;
            ShootTarget = Position2D.Zero;
            PassTarget = Position2D.Zero;
            chipOrigin = true;
            isChip = true;
            firstInState = true;
            first = true;
        }
        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId, ref int shooterId)
        {
            var tmpIds = attendIds.ToList();
            int[] allIds = new int[AttendanceSize];
            for (int i = 0; i < AttendanceSize; i++)
            {
                double minDist = double.MaxValue;
                int minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                allIds[i] = minIdx;
                tmpIds.Remove(allIds[i]);
            }
            passerId = allIds[0];
            shooterId = allIds[allIds.Length - 1];
            for (int i = 1; i < allIds.Length - 1; i++)
                ids[i - 1] = allIds[i];
            return true;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.InitialState;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }

        public override void FillInformation()
        {
            StrategyName = "Rush2TheHole";
            AttendanceSize = 4;
            About = "this strategy rush 2 the defence area";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            #region first
            if (first)
            {
                if (!CalculateIDs(Model, Attendance.Keys.ToList(), ref PositionersID, ref PasserID, ref ShooterID))
                    return;
                first = false;
            }
            #endregion
            #region States
            if (CurrentState == (int)State.InitialState)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PasserID].Location.DistanceFrom(PasserPos) < tresh
                    && Model.OurRobots[PositionersID[0]].Location.DistanceFrom(PositionersPos[0]) < tresh
                    && Model.OurRobots[PositionersID[1]].Location.DistanceFrom(PositionersPos[1]) < tresh
                    && Model.OurRobots[ShooterID].Location.DistanceFrom(ShooterPos) < tresh)
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    CurrentState = (int)State.FirstPass;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.FirstPass)
            {
                if (Model.BallState.Speed.Size > passSpeedTresh && Model.BallState.Speed.InnerProduct(Model.OurRobots[PositionersID[0]].Location - Model.BallState.Location) > 0 && Model.BallState.Location.DistanceFrom(Model.OurRobots[PasserID].Location) > 0.25)
                    CurrentState = (int)State.SecondPass;
            }
            else if (CurrentState == (int)State.SecondPass)
            {
                if (GetRole<CatchAndRotateBallRole>(PositionersID[0]).Kiick)
                {
                    if (Model.BallState.Speed.Size > passSpeedTresh)
                    {
                        if (Model.BallState.Location.DistanceFrom(Model.OurRobots[PositionersID[0]].Location) >= 0.2)
                            CurrentState = (int)State.Shoot;
                    }
                }
            }
            else if (CurrentState == (int)State.Shoot)
            {
                finishCounter++;
                if (finishCounter > finishTresh)
                    CurrentState = (int)State.Finish;
            }
            #endregion
            #region Poses And Angles
            if (CurrentState == (int)State.InitialState)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PasserPos = Model.BallState.Location + new Vector2D(initDist, 0);
                PasserAng = (Model.BallState.Location - PasserPos).AngleInDegrees;

                ShooterPos = new Position2D(-1.3, -Math.Sign(Model.BallState.Location.Y) * 0.5);
                ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;

                PositionersPos[0] = Model.BallState.Location + new Vector2D(0.6, 0);
                PositionersAng[0] = (Model.BallState.Location - PositionersPos[0]).AngleInDegrees;

                PositionersPos[1] = new Position2D(-2, Math.Sign(Model.BallState.Location.Y) * 0.5);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;

            }
            else if (CurrentState == (int)State.FirstPass)
            {

                PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PositionersID[0], PositionersPos[0], PassTarget, isChip, true);
            }
            else if (CurrentState == (int)State.SecondPass)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PassTarget = new Position2D(-2.7, 0.7);
                ShooterPos = PassTarget;
                ShooterAng = (ShootTarget - ShooterPos).AngleInDegrees;

                Position2D p0 = new Position2D(-2.5, 0.9 * Math.Sign(PasserPos.Y));
                double d = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), 0.1);
                PositionersPos[1] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                PositionersAng[1] = (ShootTarget - PositionersPos[1]).AngleInDegrees;

                p0 = new Position2D(-2.26, 0.73 * Math.Sign(PasserPos.Y));
                d = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), 0.1);
                PasserPos = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                PasserAng = (ShootTarget - PasserPos).AngleInDegrees;

                isChip = true;
                PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PositionersID[0], PositionersPos[0], PassTarget, isChip, true);
            }
            else if (CurrentState == (int)State.Shoot)
            {
                PositionersPos[0] = new Position2D(-1.7, 0);
                PositionersAng[0] = (ShootTarget - PositionersPos[0]).AngleInDegrees;
            }
            #endregion
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.InitialState)
            {
                Planner.ChangeDefaulteParams(PasserID, false);
                Planner.SetParameter(PasserID, 3, 2.5);
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, true, true, true, true);
                Planner.ChangeDefaulteParams(ShooterID, false);
                Planner.SetParameter(ShooterID, 3, 2.5);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, true, true, true, true);
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.ChangeDefaulteParams(PositionersID[i], false);
                    Planner.SetParameter(PositionersID[i], 3, 2.5);
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, true, true, true, true);
                }
            }
            else if (CurrentState == (int)State.FirstPass)
            {
                Planner.AddRotate(Model, PasserID, PositionersPos[0], 0, kickPowerType.Speed, firstPassSpeed, false, RotateDelay, false);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, true, true, true, true);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[0], typeof(CatchAndRotateBallRole)))
                    Functions[PositionersID[0]] = (eng, wmd) => GetRole<CatchAndRotateBallRole>(PositionersID[0]).CatchAndRotate(engine, Model, PositionersID[0], PassTarget, false, false, true, PassSpeed);
                Planner.Add(PositionersID[1], PositionersPos[1], PositionersAng[1], PathType.UnSafe, true, true, true, true);
                
            }
            else if (CurrentState == (int)State.SecondPass)
            {
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionersID[0], typeof(CatchAndRotateBallRole)))
                    Functions[PositionersID[0]] = (eng, wmd) => GetRole<CatchAndRotateBallRole>(PositionersID[0]).CatchAndRotate(engine, Model, PositionersID[0], PassTarget, false, false, true, PassSpeed);
                Planner.ChangeDefaulteParams(ShooterID, false);
                Planner.SetParameter(ShooterID, 6, 6);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, false, false, false, false);
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, false, false, false, false);
                //if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PasserID, typeof(CatchAndRotateBallRole)))
                //    Functions[PasserID] = (eng, wmd) => GetRole<CatchAndRotateBallRole>(PasserID).CatchAndRotate(engine, Model, PasserID, PassTarget, false, PassSpeed, false, true);
                Planner.Add(PositionersID[1], PositionersPos[1], PositionersAng[1], PathType.UnSafe, false, false, false, false);
                
            }
            else if (CurrentState == (int)State.Shoot)
            {
                Planner.Add(PasserID, PasserPos, PasserAng, PathType.UnSafe, false, true, false, false);
                
                for (int i = 0; i < PositionersPos.Length; i++)
                {
                    Planner.Add(PositionersID[i], PositionersPos[i], PositionersAng[i], PathType.UnSafe, false, false, false, false);
                }
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, ShooterID, typeof(OneTouchRole)))
                    Functions[ShooterID] = (eng, wmd) => GetRole<OneTouchRole>(ShooterID).Perform(engine, Model, ShooterID, Model.OurRobots[PasserID], isChip, ShootTarget, KickSpeed, false, PassSpeed);
            }
            return CurrentlyAssignedRoles;
        }

        enum State
        {
            InitialState,
            FirstPass,
            SecondPass,
            Shoot,
            Finish
        }
    }
}
