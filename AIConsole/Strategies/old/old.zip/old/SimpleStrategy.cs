﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;

namespace MRL.SSL.AIConsole.Strategies
{
    public class SimpleStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        bool first = true;
        Synchronizer sync = new Synchronizer();

        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            sync.Reset();
            first = true;
            isInint = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.First;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
        }

        public override void FillInformation()
        {
            StrategyName = "SimpleStrategy";
            AttendanceSize = 1;
            About = "this is Simple strategy!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            throw new NotImplementedException();
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            throw new NotImplementedException();
        }
        public enum State
        {
            First,
            Go,
            Finish
        }
    }
}
