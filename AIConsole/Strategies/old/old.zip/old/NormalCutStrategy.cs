﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class NormalCutStrategy:StrategyBase
    {
        int Counter = 0;
        Synchronizer sync = new Synchronizer();
        bool first = true;

        int passerID = 0;
        int cutterID = 0;
        int onetouchID = 0;
        
        Position2D passPos = new Position2D(-1.5, 1.8);
        Position2D passerPos = Position2D.Zero;
        Position2D cutterPos = new Position2D(2.5, 1.2);
        Position2D otFirstPos = new Position2D(-2.5, 1.7);
        Position2D onetouchPos = Position2D.Zero;
        Random rand = new Random();
        double passerAngle = 0;
        double cutterAngle = 0;
        double onetouchAngle = 0;
        int Counter2 = 0;
        bool gotouch = false;
        double passSpeed = 2.3;
        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            sync.Reset();
            first = true;
            isInint = false;
            gotouch = false;
        }
        
        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.FirstPosition;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }

        public override void FillInformation()
        {
            StrategyName = "NormalCut";
            AttendanceSize = 3;
            About = "this is Cut strategy that will cut skuba ";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            if (first)
            {
                double r = rand.NextDouble();
                passSpeed = (r > 0.5) ? 5 : 5;
                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && otFirstPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = otFirstPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                onetouchID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w != onetouchID).ToList();
                if (list.Count > 0)
                    cutterID = list[0];
                cutterPos.Y = -Math.Sign(Model.BallState.Location.Y) * Math.Abs(cutterPos.Y);
                otFirstPos.Y = -Math.Sign(Model.BallState.Location.Y) * Math.Abs(otFirstPos.Y);
                passPos.Y = -Math.Sign(Model.BallState.Location.Y) * Math.Abs(passPos.Y);
                cutterAngle = (GameParameters.OppGoalCenter - cutterPos).AngleInDegrees;
                first = false;
            }
            if (CurrentState == (int)State.FirstPosition)
            {
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutterID].Location.DistanceFrom(cutterPos) < 0.01 && Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) < 0.01)
                {
                    Counter2++;
                }
                if (Counter2 >= 60)
                    CurrentState = (int)State.OneTouchMove;
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutterID].Location.DistanceFrom(cutterPos) < 0.01 && Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) < 1)
                {
                    CurrentState = (int)State.Cut;
                }
            }
            else if (CurrentState == (int)State.Cut)
            {
                Counter++;
                if (Counter > 300)
                    CurrentState = (int)State.Finish;
            }

            if (CurrentState == (int)State.FirstPosition)
            {
                onetouchPos = otFirstPos;
                onetouchAngle = (GameParameters.OppGoalCenter - onetouchPos).AngleInDegrees;
                passerPos = Model.BallState.Location + (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6);
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                onetouchPos = passPos - (GameParameters.OppGoalCenter - passPos).GetNormalizeToCopy(0.1);
                onetouchAngle = (GameParameters.OppGoalCenter - onetouchPos).AngleInDegrees;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>(Model.OurRobots.Count);
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)State.FirstPosition)
            {
                gotouch = false;
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutterID, new SingleObjectState(cutterPos, Vector2D.Zero, (float)cutterAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.OneTouchMove)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutterID, new SingleObjectState(cutterPos, Vector2D.Zero, (float)cutterAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.Cut)
            {
                bool gotopoint = true;
                if (Model.BallState.Speed.Size < 0.5 || Model.OurRobots[onetouchID].Location.DistanceFrom(onetouchPos) > 0.3)
                {
                    Planner.Add(onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), PathType.UnSafe, true, true, true, true);
                    gotopoint = false;
                }
                if (Model.BallState.Speed.Size >= 0.5)
                {
                    gotouch = true;
                }
                if (gotouch)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, onetouchID, typeof(OneTouchRole)))
                        Functions[onetouchID] = (eng, wmd) => GetRole<OneTouchRole>(onetouchID).Perform(eng, wmd, onetouchID, new SingleObjectState(onetouchPos, Vector2D.Zero, (float)onetouchAngle), null, false, GameParameters.OppGoalCenter, 7, false, gotopoint);
                }

                sync.Cut(engine, Model, passerID, Model.BallState.Location + new Vector2D(0.3, 0), passPos, false, passSpeed, kickPowerType.Speed, 60, cutterID, GameParameters.OppGoalCenter, 100, false, kickPowerType.Power);
            }
            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }
        public enum State
        {
            FirstPosition,
            OneTouchMove,
            Cut,
            Finish
        }
    }
}
