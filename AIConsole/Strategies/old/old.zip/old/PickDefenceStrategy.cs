﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.AIConsole.Roles;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.Planning.GamePlanner.Types;

namespace MRL.SSL.AIConsole.Strategies
{
    class PickDefenceStrategy : StrategyBase
    {
        
        const double tresh = 0.03, stuckTresh = 0.23, angleTresh = 2, waitTresh = 20, finishTresh = 100, initDist = 0.22, maxWaitTresh = 360, passSpeedTresh = 0.08, behindBallTresh = 0.07;
        const int strategyAttendance = 5, positionersAttendance = 3;

        bool first, firstInState, InitialPosCal, chipOrigin, chip, passed, inRot;
        int PasserID, ShooterID, initialPosCounter, finishCounter, timeLimitCounter, RotateDelay, defenderIdx, rotateCounter;
        double GoaliAng, PasserAng, ShooterAng, RotateTeta, KickPower, PassSpeed, DefenderAng;
        Position2D PasserPos, ShooterPos, GoaliPos, ShootTarget, PassTarget, DefenderPos;
        
        int[] PositionerIDs;
        double[] PositionerAngs;
        Position2D[] PositionerPoses;

        Syncronizer Sync;
        
        public override void ResetState()
        {
            first = true;
            InitialPosCal = true;
            chipOrigin = false;
            chip = false;
            firstInState = true;
            passed = false;
            inRot = false;
            rotateCounter = 2;
            PasserID = -1;
            ShooterID = -1;
            initialPosCounter = 0;
            finishCounter = 0;
            timeLimitCounter = 0;
            RotateDelay = 60;

            GoaliAng = 0;
            PasserAng = 0; 
            ShooterAng = 0;
            RotateTeta = 90;
            KickPower = 8;
            PassSpeed = 4;
            DefenderAng = 0;

            PassTarget = Position2D.Zero;
            DefenderPos = Position2D.Zero;
            defenderIdx = 1;
            PositionerIDs = new int[positionersAttendance];
            PositionerAngs = new double[positionersAttendance];
            PositionerPoses = new Position2D[positionersAttendance];
            
            for (int i = 0; i < positionersAttendance; i++)
            {
                PositionerPoses[i] = Position2D.Zero;
            }

            if (Sync != null)
            {
                Sync.Reset();
            }
            else
            {
                Sync = new Syncronizer();
            }
        }

        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.InitialState;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }

        public override void FillInformation()
        {
            StrategyName = "PickDefence";
            AttendanceSize = 6;
            About = "this strategy attack opponents with 5 attacker!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        private bool CalculateIDs(WorldModel Model, List<int> attendIds, ref int[] ids, ref int passerId, ref int shooterId)
        {
            var tmpIds = attendIds.ToList();
            int[] allIds = new int[strategyAttendance];
            for (int i = 0; i < strategyAttendance; i++)
            {
                double minDist = double.MaxValue;
                int minIdx = -1;
                foreach (var item in tmpIds.ToList())
                {
                    if (Model.OurRobots.ContainsKey(item) && Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y) < minDist)
                    {
                        minDist = Math.Abs(Model.OurRobots[item].Location.Y - Model.BallState.Location.Y);
                        minIdx = item;
                    }
                }
                if (minIdx == -1)
                    return false;
                allIds[i] = minIdx;
                tmpIds.Remove(allIds[i]);
            }
            passerId = allIds[0];
            shooterId = allIds[allIds.Length - 1];
            for (int i = 1; i < allIds.Length - 1; i++)
                ids[i - 1] = allIds[i];
            return true;
        }
        private void CalulatePosAndAngles(WorldModel Model, Position2D shootTarget, ref Position2D[] poses, ref double[] anges, ref Position2D shooterPos, ref double shooterAng, int stateIdx)
        {
            double margin = 0.25;
            if (stateIdx == 0)
            {
                shooterPos = new Position2D(1.2, Math.Sign(-Model.BallState.Location.Y) * (Math.Abs(GameParameters.OurLeftCorner.Y) - (RobotParameters.OurRobotParams.Diameter + 0.05)));
                shooterAng = (shootTarget - shooterPos).AngleInDegrees;
                Position2D p0 = new Position2D(-2, 0.3 * Math.Sign(Model.BallState.Location.Y));
                double d = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), margin);
                poses[0] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                Position2D p1 = p0 + new Vector2D(0, Math.Sign(Model.BallState.Location.Y) * 0.3);
                d = GameParameters.SafeRadi(new SingleObjectState(-p1, Vector2D.Zero, 0), margin);
                poses[1] = GameParameters.OppGoalCenter + (p1 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                poses[2] = poses[0] + (poses[0] - shootTarget).GetNormalizeToCopy(0.4);
             }
            else if (stateIdx == 1)
            {
                shooterPos = new Position2D(1.2, Math.Sign(-Model.BallState.Location.Y) * (Math.Abs(GameParameters.OurLeftCorner.Y) - (RobotParameters.OurRobotParams.Diameter + 0.05)));
                shooterAng = (shootTarget - shooterPos).AngleInDegrees;
                poses[2] = poses[1];
                Position2D p0 = new Position2D(-2.37, 0.9 * Math.Sign(Model.BallState.Location.Y));
                double d = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), margin);
                poses[0] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                Position2D p1 = p0 + new Vector2D(-0.2, Math.Sign(Model.BallState.Location.Y) * 0.2);
                d = GameParameters.SafeRadi(new SingleObjectState(-p1, Vector2D.Zero, 0), margin);
                poses[1] = GameParameters.OppGoalCenter + (p1 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
            }
            else if (stateIdx == 2)
            {
                Position2D p0 = new Position2D(-2, 0.1 * Math.Sign(Model.BallState.Location.Y));
                double d = GameParameters.SafeRadi(new SingleObjectState(-p0, Vector2D.Zero, 0), margin);
                poses[2] = GameParameters.OppGoalCenter + (p0 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
                Position2D p1 = p0 + new Vector2D(0, Math.Sign(Model.BallState.Location.Y) * 0.2);
                d = GameParameters.SafeRadi(new SingleObjectState(-p1, Vector2D.Zero, 0), margin);
                poses[0] = GameParameters.OppGoalCenter + (p1 - GameParameters.OppGoalCenter).GetNormalizeToCopy(d);
            }
            for (int i = 0; i < poses.Length; i++)
            {
                if (stateIdx != 2 || i != poses.Length - 1)
                    anges[i] = (shootTarget - poses[i]).AngleInDegrees;
            }
        }
        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            #region SET ID
            if (first)
            {
                var tmpids = RemoveGoaliID(Model, Attendance);
                if (!CalculateIDs(Model, tmpids, ref PositionerIDs, ref PasserID, ref ShooterID))
                    return;
                first = false;
            }
            #endregion
            #region Set State
            if (CurrentState == (int)State.InitialState)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PositionerIDs[0]].Location.DistanceFrom(PositionerPoses[0]) < stuckTresh
                    && Model.OurRobots[PositionerIDs[1]].Location.DistanceFrom(PositionerPoses[1]) < stuckTresh
                    && Model.OurRobots[PositionerIDs[2]].Location.DistanceFrom(PositionerPoses[2]) < stuckTresh
                    && Model.OurRobots[ShooterID].Location.DistanceFrom(ShooterPos) < tresh
                    && (!Model.GoalieID.HasValue || !Model.OurRobots.ContainsKey(Model.GoalieID.Value) || Model.OurRobots[Model.GoalieID.Value].Location.DistanceFrom(GoaliPos) < tresh))
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    CurrentState = (int)State.FakeMove;
                    InitialPosCal = true;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.FakeMove)
            {
                timeLimitCounter++;
                if (Model.OurRobots[PositionerIDs[0]].Location.DistanceFrom(PositionerPoses[0]) < stuckTresh
                     && Model.OurRobots[PositionerIDs[1]].Location.DistanceFrom(PositionerPoses[1]) < stuckTresh
                     && Model.OurRobots[PositionerIDs[2]].Location.DistanceFrom(PositionerPoses[2]) < stuckTresh)
                    initialPosCounter++;

                if (initialPosCounter > waitTresh || timeLimitCounter > maxWaitTresh)
                {
                    CurrentState = (int)State.Go;
                    InitialPosCal = true;
                    firstInState = true;
                    timeLimitCounter = 0;
                    initialPosCounter = 0;
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                timeLimitCounter++;
                if (passed)
                    finishCounter++;
                if (Sync.Finished || Sync.Failed || finishCounter > finishTresh || timeLimitCounter > maxWaitTresh)
                    CurrentState = (int)State.Finish;
            }

            #endregion
            #region Defence Info
            CalculateDefenderInfo(engine, Model, out DefenderPos, out GoaliPos, out DefenderAng, out GoaliAng);
            #endregion
            #region SetPos
            if (CurrentState == (int)State.InitialState)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PasserPos = Model.BallState.Location + (Model.BallState.Location - ShootTarget).GetNormalizeToCopy(initDist);
                PasserAng = (ShootTarget - PasserPos).AngleInDegrees;
                if (InitialPosCal)
                {
                    CalulatePosAndAngles(Model, ShootTarget, ref PositionerPoses, ref PositionerAngs, ref ShooterPos, ref ShooterAng, 0);
                    InitialPosCal = false;
                }
            }
            else if (CurrentState == (int)State.FakeMove)
            {
                ShootTarget = GameParameters.OppGoalCenter;
                PasserPos = Model.BallState.Location + (Model.BallState.Location - ShootTarget).GetNormalizeToCopy(initDist);
                PasserAng = (ShootTarget - PasserPos).AngleInDegrees;
                if (InitialPosCal)
                {
                    CalulatePosAndAngles(Model, ShootTarget, ref PositionerPoses, ref PositionerAngs, ref ShooterPos, ref ShooterAng, 1);
                    InitialPosCal = false;
                }
            }
            else if (CurrentState == (int)State.Go)
            {
                if (firstInState)
                {

                    ShootTarget = GameParameters.OppGoalCenter;
                    double width = 0.6, heigth = 1.5, step = 0.3;
                    Position2D topLeft = new Position2D(Model.BallState.Location.X + 0.5, (Math.Sign(Model.BallState.Location.Y) >= 0) ? -Math.Min(0.5 + heigth, Math.Abs(GameParameters.OurLeftCorner.Y) - 0.2) : Math.Min(0.5, Math.Abs(GameParameters.OurLeftCorner.Y) - 0.2 - heigth));

                    Position2D bestPoint = Position2D.Zero;
                    chip = chipOrigin;
                    engine.GameInfo.BestPassPoint(Model, ShootTarget, topLeft, width, heigth, (int)(width / step), (int)(heigth / step), ref chip, ref bestPoint);
                    chipOrigin = chip;
                    PassTarget = bestPoint;

                    Vector2D BallTarget = PassTarget - Model.BallState.Location;
                    Vector2D InitBall = (GameParameters.OppGoalCenter - Model.BallState.Location);
                    double Teta = Vector2D.AngleBetweenInDegrees(BallTarget, InitBall);
                    double sgn = Math.Sign(Teta);
                    Teta = Math.Round(Math.Abs(Teta));
                    Teta = Teta - (Teta % 10);
                    if (Teta > 120 && Teta < 150)
                        Teta = 120;
                    else if (Teta >= 150)
                        Teta = 180;
                    else if (Teta > 15 && Teta < 30)
                        Teta = 30;
                    else if (Teta < 15)
                        Teta = 0;
                    Teta *= sgn;
                    Teta = Teta.ToRadian();
                    PassTarget = Model.BallState.Location + Vector2D.FromAngleSize(InitBall.AngleInRadians + Teta, Model.BallState.Location.DistanceFrom(PassTarget));

                    double goodness;
                    var GoodPointInGoal = engine.GameInfo.GetAGoodTargetPointInGoal(Model, null, PassTarget, out goodness, GameParameters.OppGoalLeft, GameParameters.OppGoalRight, true, false, null);
                    if (GoodPointInGoal.HasValue)
                        ShootTarget = GoodPointInGoal.Value;

                    firstInState = false;
                }
                if (Sync.SyncStarted)
                {
                    if (InitialPosCal)
                    {
                        CalulatePosAndAngles(Model, ShootTarget, ref PositionerPoses, ref PositionerAngs, ref ShooterPos, ref ShooterAng, 2);
                        InitialPosCal = false;
                    }
                }
                if (inRot && Model.BallState.Speed.Size > passSpeedTresh)
                    passed = true;
                chip = chipOrigin;
                if (!passed && !chipOrigin)
                {
                    Obstacles obs = new Obstacles(Model);
                    obs.AddObstacle(1, 0, 0, 0, new List<int>() { PasserID }, null);
                    chip = obs.Meet(Model.BallState, new SingleObjectState(PassTarget, Vector2D.Zero, 0), 0.07);
                }
                PassSpeed = engine.GameInfo.CalculateKickSpeed(Model, PasserID, Model.BallState.Location, PassTarget, chip, true);
                if (PassTarget.X > -1.9 && chip)
                    PassSpeed = 0.9;
            }
            #endregion

        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();
            if (CurrentState == (int)State.InitialState)
            {
                if (Planner.AddRotate(Model, PasserID, ShootTarget, PasserPos, kickPowerType.Speed, PassSpeed, false, rotateCounter, true).IsInRotateDelay)
                {
                    rotateCounter++;
                    inRot = true;
                }
                Planner.ChangeDefaulteParams(ShooterID, false);
                Planner.SetParameter(ShooterID, 3, 2.5);
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, true, true, true, true);
                for(int i =0; i < PositionerPoses.Length;i++)
                {
                    Planner.Add(PositionerIDs[i], PositionerPoses[i], PositionerAngs[i], PathType.UnSafe, true, true, true, true);
                }
            }
            else if (CurrentState == (int)State.FakeMove)
            {
                if (Planner.AddRotate(Model, PasserID, ShootTarget, PasserPos, kickPowerType.Speed, PassSpeed, false, rotateCounter, true).IsInRotateDelay)
                {
                    rotateCounter++;
                    inRot = true;
                }
                Planner.Add(ShooterID, ShooterPos, ShooterAng, PathType.UnSafe, true, true, true, true);
                Planner.Add(PositionerIDs[1], PositionerPoses[1], PositionerAngs[1], PathType.UnSafe, false, true, false, true);
                Planner.Add(PositionerIDs[0], PositionerPoses[0], PositionerAngs[0], PathType.UnSafe, false, false, false, true);
                if (Model.OurRobots[PositionerIDs[0]].Location.DistanceFrom(PositionerPoses[2]) > 0.08)
                    Planner.Add(PositionerIDs[2], PositionerPoses[2], PositionerAngs[2], PathType.UnSafe, false, false, false, false);
            }
            else if (CurrentState == (int)State.Go)
            {
                if (!chip)
                    Sync.SyncDirectPass(engine, Model, PasserID, PasserPos, ShooterID, PassTarget, ShootTarget, PassSpeed, KickPower, RotateDelay, rotateCounter);
                else
                    Sync.SyncChipPass(engine, Model, PasserID, PasserPos, ShooterID, PassTarget, ShootTarget, PassSpeed, KickPower, RotateDelay, rotateCounter);
                if (Sync.InRotate)
                    inRot = true;
                Planner.Add(PositionerIDs[2], PositionerPoses[2], PositionerAngs[2], PathType.UnSafe, false, false, false, true);
           //     if (Model.OurRobots[PositionerIDs[2]].Location.DistanceFrom(PositionerPoses[2]) > 0.08)
                {
                 //   Planner.Add(PositionerIDs[1], PositionerPoses[1], PositionerAngs[1], PathType.UnSafe, false, false, false, true);
                    Planner.Add(PositionerIDs[0], PositionerPoses[0], PositionerAngs[0], PathType.UnSafe, false, false, false, true);
                }
                if (!Sync.SyncStarted)
                    Planner.Add(PositionerIDs[defenderIdx], PositionerPoses[defenderIdx], PositionerAngs[defenderIdx], PathType.UnSafe, false, false, false, true);
                else
                {
                    if (Model.OurRobots[PositionerIDs[defenderIdx]].Location.DistanceFrom(DefenderPos) > 1)
                        Planner.Add(PositionerIDs[defenderIdx], DefenderPos, DefenderAng, PathType.UnSafe, true, true, true, true);
                    else 
                        if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, PositionerIDs[defenderIdx], typeof(DefenderCornerRole1)))
                        Functions[PositionerIDs[defenderIdx]] = (eng, wmd) => GetRole<DefenderCornerRole1>(PositionerIDs[defenderIdx]).Run(engine, Model, PositionerIDs[defenderIdx], DefenderPos, DefenderAng);
                }
            }
            if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, Model.GoalieID, typeof(GoalieCornerRole)))
                Functions[Model.GoalieID.Value] = (eng, wmd) => GetRole<GoalieCornerRole>(Model.GoalieID.Value).Run(engine,Model,Model.GoalieID.Value,GoaliPos,GoaliAng);
            return CurrentlyAssignedRoles;
        }
        private void CalculateDefenderInfo(GameStrategyEngine engine, WorldModel Model, out Position2D defPos, out Position2D goalipos, out double defAng, out double goaliang)
        {
            List<DefenderCommand> defendcommands = new List<DefenderCommand>();
            int? id = null;
            defendcommands.Add(new DefenderCommand()
            {
                RoleType = typeof(GoalieCornerRole)
            });
            defendcommands.Add(new DefenderCommand()
            {
                RoleType = typeof(DefenderCornerRole1),
                OppID = engine.GameInfo.OppTeam.Scores.Count > 0 ? engine.GameInfo.OppTeam.Scores.ElementAt(0).Key : id
            });
            var infos = FreekickDefence.Match(engine, Model, defendcommands);
            var gol = infos.SingleOrDefault(s => s.RoleType == typeof(GoalieCornerRole));
            var normal1 = infos.SingleOrDefault(s => s.RoleType == typeof(DefenderCornerRole1));
            goalipos = (gol.DefenderPosition.HasValue) ? gol.DefenderPosition.Value : Position2D.Zero;
            goaliang = gol.Teta;
            defPos = (normal1.DefenderPosition.HasValue) ? normal1.DefenderPosition.Value : Position2D.Zero;
            defAng = normal1.Teta;
        }
        private List<int> RemoveGoaliID(WorldModel Model, Dictionary<int, SingleObjectState> Attendance)
        {
            return (Model.GoalieID.HasValue) ? Attendance.Keys.Where(w => w != Model.GoalieID.Value).ToList() : Attendance.Keys.ToList();
        }
        public enum State
        {
            InitialState,
            FakeMove,
            Go,
            Finish
        }

    }
}
