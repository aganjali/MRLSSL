﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class HeavyCutStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        int passerID = 0;
        int cutterID = 0;
        int onetouch1ID = 0;
        int onetouch2ID = 0;

        Position2D passPos1 = new Position2D(-1.5, 1.6);
        Position2D passPos2 = new Position2D(-1.9, 1.9);
        Position2D passPoint = Position2D.Zero;

        Position2D passerPos = Position2D.Zero;

        Position2D cutterPos = new Position2D(2.5, 1.1);

        Position2D ot1FirstPos = new Position2D(-2.5, 1.7);
        Position2D ot2FirstPos = new Position2D(-2.5, 1.7);

        Position2D onetouch1Pos = Position2D.Zero;
        Position2D onetouch2Pos = Position2D.Zero;

        double passerAngle = 0;
        double cutterAngle = 0;
        double onetouch1Angle = 0;
        double onetouch2Angle = 0;
        bool gotouch1 = false;
        bool gotouch2 = false;
        int Counter3 = 0;
        Synchronizer sync = new Synchronizer();
        bool first = true;
        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter3 = 0;
            Counter2 = 0;
            sync.Reset();
            first = true;
            isInint = false;
            gotouch1 = false;
            gotouch2 = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.First;
            InitialState = 0;
            FinalState = 3;
            TrapState = 3;
        }

        public override void FillInformation()
        {
            StrategyName = "HeavyCut";
            AttendanceSize = 4;
            About = "this is Heavy Cut strategy that will cut skuba Heavily!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        Random rand = new Random();
        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            if (first)
            {
                double r = rand.NextDouble();
                r = (r > 0.5) ? 1 : -1;

                cutterPos.Y = - Math.Sign(Model.BallState.Location.Y) * Math.Abs(cutterPos.Y);
                cutterAngle = (GameParameters.OppGoalCenter - cutterPos).AngleInDegrees;

                ot1FirstPos = Model.BallState.Location + Vector2D.FromAngleSize(-Math.Sign(Model.BallState.Location.Y) * 45 * Math.PI / 180, 1);
                ot2FirstPos = Model.BallState.Location + Vector2D.FromAngleSize(-Math.Sign(Model.BallState.Location.Y) * 25 * Math.PI / 180, 1);

                passPos1 = new Position2D(Math.Min(Math.Abs(Model.BallState.Location.X - 0.7), 3.0) * Math.Sign(Model.BallState.Location.X - 0.7), -Model.BallState.Location.Y);
                passPos2 = new Position2D(Math.Min(Math.Abs(Model.BallState.Location.X + 0.7), 3.0) * Math.Sign(Model.BallState.Location.X + 0.7), -Math.Sign(Model.BallState.Location.Y) * (Math.Abs(Model.BallState.Location.Y) - 0.3));

                passPoint = (r > 0) ? passPos1 : passPos2;
                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && ot1FirstPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = ot1FirstPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                onetouch1ID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && item.Key != onetouch1ID && cutterPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = cutterPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                cutterID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w != onetouch1ID && w != cutterID).ToList();
                if (list.Count > 0)
                    onetouch2ID = list[0];

                first = false;
            }

            if (CurrentState == (int)State.First)
            {
                Counter3 ++;
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutterID].Location.DistanceFrom(cutterPos) < 0.01 && Model.OurRobots[onetouch1ID].Location.DistanceFrom(onetouch1Pos) < 0.01 && Model.OurRobots[onetouch2ID].Location.DistanceFrom(onetouch2Pos) < 0.01)
                {
                    Counter2++;
                }
                if (Counter2 > 60 || Counter3 > 300)
                {
                    CurrentState = (int)State.OneTouchMove;
                    Counter3 = 0;
                }
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                Counter3++;
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[cutterID].Location.DistanceFrom(cutterPos) < 0.01 && Model.OurRobots[onetouch1ID].Location.DistanceFrom(onetouch1Pos) < 1 && Model.OurRobots[onetouch2ID].Location.DistanceFrom(onetouch2Pos) < 1 || Counter3 > 300)
                {
                    CurrentState = (int)State.Cut;
                }
            }
            else if (CurrentState == (int)State.Cut)
            {
                Counter++;
                if (Counter > 300)
                    CurrentState = (int)State.Finish;
            }

            if (CurrentState == (int)State.First)
            {
                onetouch1Pos = ot1FirstPos;
                onetouch1Angle = (GameParameters.OppGoalCenter - onetouch1Pos).AngleInDegrees;
                
                onetouch2Pos = ot2FirstPos;
                onetouch2Angle = (GameParameters.OppGoalCenter - onetouch2Pos).AngleInDegrees;

                passerPos = Model.BallState.Location + (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6);
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;
            }
            else if (CurrentState == (int)State.OneTouchMove)
            {
                onetouch1Pos = passPos1 - (GameParameters.OppGoalCenter - passPos1).GetNormalizeToCopy(0.1);
                onetouch1Angle = (GameParameters.OppGoalCenter - onetouch1Pos).AngleInDegrees;
                
                onetouch2Pos = passPos2 - (GameParameters.OppGoalCenter - passPos2).GetNormalizeToCopy(0.1);
                onetouch2Angle = (GameParameters.OppGoalCenter - onetouch2Pos).AngleInDegrees;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>(Model.OurRobots.Count);
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)State.First)
            {
                gotouch1 = false;
                gotouch2 = false;
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutterID, new SingleObjectState(cutterPos, Vector2D.Zero, (float)cutterAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouch1ID, new SingleObjectState(onetouch1Pos, Vector2D.Zero, (float)onetouch1Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouch2ID, new SingleObjectState(onetouch2Pos, Vector2D.Zero, (float)onetouch2Angle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.OneTouchMove)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(cutterID, new SingleObjectState(cutterPos, Vector2D.Zero, (float)cutterAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouch1ID, new SingleObjectState(onetouch1Pos, Vector2D.Zero, (float)onetouch1Angle), PathType.UnSafe, true, true, true, true);
                Planner.Add(onetouch2ID, new SingleObjectState(onetouch2Pos, Vector2D.Zero, (float)onetouch2Angle), PathType.UnSafe, true, true, true, true);
            }
            if (CurrentState == (int)State.Cut)
            {
                bool gotopoint1 = true;
                if (Model.BallState.Speed.Size < 0.5 || Model.OurRobots[onetouch1ID].Location.DistanceFrom(onetouch1Pos) > 0.2)
                {
                    Planner.Add(onetouch1ID, new SingleObjectState(onetouch1Pos, Vector2D.Zero, (float)onetouch1Angle), PathType.UnSafe, true, true, true, true);
                    gotopoint1 = false;
                }
                if (Model.BallState.Speed.Size >= 0.5)
                {
                    gotouch1 = true;
                }
                if (gotouch1)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, onetouch1ID, typeof(OneTouchRole)))
                        Functions[onetouch1ID] = (eng, wmd) => GetRole<OneTouchRole>(onetouch1ID).Perform(eng, wmd, onetouch1ID, new SingleObjectState(onetouch1Pos, Vector2D.Zero, (float)onetouch1Angle), null, false, GameParameters.OppGoalCenter, 7, false, gotopoint1);
                }

                bool gotopoint2 = true;
                if (Model.BallState.Speed.Size < 0.5 || Model.OurRobots[onetouch2ID].Location.DistanceFrom(onetouch2Pos) > 0.3)
                {
                    Planner.Add(onetouch2ID, new SingleObjectState(onetouch2Pos, Vector2D.Zero, (float)onetouch2Angle), PathType.UnSafe, true, true, true, true);
                    gotopoint2 = false;
                }
                if (Model.BallState.Speed.Size >= 0.5)
                {
                    gotouch2 = true;
                }
                if (gotouch2)
                {
                    if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, onetouch2ID, typeof(OneTouchRole)))
                        Functions[onetouch2ID] = (eng, wmd) => GetRole<OneTouchRole>(onetouch2ID).Perform(eng, wmd, onetouch2ID, new SingleObjectState(onetouch2Pos, Vector2D.Zero, (float)onetouch2Angle), null, false, GameParameters.OppGoalCenter, 7, false, gotopoint2);
                }
                sync.Cut(engine, Model, passerID, Model.BallState.Location + new Vector2D(0.3, 0), passPoint, false, 2.7, kickPowerType.Speed, 60, cutterID, GameParameters.OppGoalCenter, 100, false, kickPowerType.Power);
            }
            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }
        public enum State
        {
            First,
            OneTouchMove,
            Cut,
            Finish
        }
    }
}
