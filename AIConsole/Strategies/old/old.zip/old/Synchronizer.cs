﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Skills;
using System.Drawing;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class Synchronizer
    {
        public Synchronizer()
        {
        }

        int time = 0;
        const double kRotateDirect = 1;
        const double kOnetouchMove = 0.8;
        const double kRotateChip = 1;
        const double kChipOneTouchMove = .1;

        const double kRotateCut = 1;
        const double kCutMove = 1;
        const double kExtendCut = 0.35;
        const double k = 0.78;
        int time2Pass = 0, time2Move = 0;

        bool first = true;
        public void Reset()
        {
            first = true;
            time = 0;
            time2Pass = 0;
            time2Move = 0;
            gotoOnetouch = false;
            ot = false;
            onetouch = new OneTouchSkill();
            cutRole = new CutBallRole();
        }
        OneTouchSkill onetouch = new OneTouchSkill();
        CutBallRole cutRole = new CutBallRole();
        bool ot = false;
        bool gotoOnetouch = false;
        Position2D positionerTarget = Position2D.Zero;
        public bool DirectOneTouch(GameStrategyEngine eng, WorldModel Model, int PasserID, Position2D PasserInitilize, Position2D PassTarget, double passSpeed, kickPowerType passPowerType, int RotateDelay, int PositionerID, Position2D ShootTarget, double shootSpeed, bool isChip, kickPowerType shootPowerType, bool avoidOppZone)
        {
            double totalTime = 0;
       
            SingleObjectState passerRobot = Model.OurRobots[PasserID];
            SingleObjectState positionerRobot = Model.OurRobots[PositionerID];

            Line RobotTarget = new Line(positionerRobot.Location, ShootTarget);
            Line BallSpeed = new Line(Model.BallState.Location, Model.BallState.Location + Model.BallState.Speed.GetNormalizeToCopy(1));
            Position2D inter = Position2D.Zero;
 
           
            if (first)
            {
                positionerTarget = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(0.1);
                Vector2D rotateInitVec = (Model.BallState.Location - PassTarget).GetNormalizeToCopy(0.3);
                time2Pass = Planner.GetRotateTime(Model, PasserInitilize, PassTarget);
                time2Pass += (int)(Planner.GetMotionTime(Model,PasserID, passerRobot.Location, rotateInitVec + Model.BallState.Location));
                time2Pass += Planner.GetMotionTime(Model, PasserID, rotateInitVec + Model.BallState.Location, rotateInitVec.GetNormalizeToCopy(0.13) + Model.BallState.Location);
                time2Pass += RotateDelay;
                time2Pass = (int)(kRotateDirect * time2Pass);
                
                time2Move = (int)(kOnetouchMove * Planner.GetMotionTime(Model, PositionerID, positionerRobot.Location, positionerTarget));
                first = false;
            }
            bool f = false;
            if (Model.BallState.Speed.Size > 0.1)
            {
                ot = true;
            }
            int dt = Math.Abs(time2Move - time2Pass);
            if (time2Pass > time2Move)
            {
                if (time < dt)
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, false, RotateDelay,false);
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, false, RotateDelay,false);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;

                }
            }
            else
            {
                if (time < dt)
                {
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, false, RotateDelay,false);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
            }
           
            if (ot)
            {
                Position2D tar;
                if (Model.BallState.Speed.Y >= 0)
                    tar = GameParameters.OppGoalLeft;
                else
                {
                    tar = GameParameters.OppGoalRight;
                }
                Stop(Model, PasserID);
                onetouch.Perform(eng, Model, PositionerID,new SingleObjectState(PassTarget,Vector2D.Zero,0), null, false, tar, shootSpeed, isChip, gotoOnetouch);
                positionerTarget = onetouch.OneTouchPoint;
                if (onetouch.OneTouchPoint.DistanceFrom(positionerRobot.Location) < 0.5)
                    gotoOnetouch = true;
            }

            if (f)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.3) { DrawPen = new Pen(Color.Red, 0.01f) });
            if(ot)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.5) { DrawPen = new Pen(Color.Blue, 0.01f) });
            DrawingObjects.AddObject(new Circle(positionerTarget, 0.1) { DrawPen = new Pen(Color.Red, 0.01f) });
            DrawingObjects.AddObject(new Circle(PassTarget, 0.2) { DrawPen = new Pen(Color.YellowGreen, 0.01f) });
            time++;
            return time == totalTime;
        }
        public bool DirectOneTouch(GameStrategyEngine eng, WorldModel Model, int PasserID, double Teta, Position2D PassTarget, double passSpeed, kickPowerType passPowerType, int RotateDelay, int PositionerID, Position2D ShootTarget, double shootSpeed, bool isChip, kickPowerType shootPowerType, bool avoidOppZone)
        {
            double totalTime = 0;

            SingleObjectState passerRobot = Model.OurRobots[PasserID];
            SingleObjectState positionerRobot = Model.OurRobots[PositionerID];

            Line RobotTarget = new Line(positionerRobot.Location, ShootTarget);
            Line BallSpeed = new Line(Model.BallState.Location, Model.BallState.Location + Model.BallState.Speed.GetNormalizeToCopy(1));
            Position2D inter = Position2D.Zero;


            if (first)
            {
                positionerTarget = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(0.1);
                Vector2D rotateInitVec = (Model.BallState.Location - PassTarget).GetNormalizeToCopy(0.3);
                time2Pass = Planner.GetRotateTime(Teta);
                time2Pass += (int)(Planner.GetMotionTime(Model, PasserID, passerRobot.Location, rotateInitVec + Model.BallState.Location));
                time2Pass += Planner.GetMotionTime(Model, PasserID, rotateInitVec + Model.BallState.Location, rotateInitVec.GetNormalizeToCopy(0.13) + Model.BallState.Location);
                time2Pass += RotateDelay;
                time2Pass = (int)(kRotateDirect * time2Pass);

                time2Move = (int)(kOnetouchMove * Planner.GetMotionTime(Model, PositionerID, positionerRobot.Location, positionerTarget));
                first = false;
            }
            bool f = false;
            if (Model.BallState.Speed.Size > 0.1)
            {
                ot = true;
            }
            int dt = Math.Abs(time2Move - time2Pass);
            if (time2Pass > time2Move)
            {
                if (time < dt)
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, false, RotateDelay,false);
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, false, RotateDelay,false);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;

                }
            }
            else
            {
                if (time < dt)
                {
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, false, RotateDelay,false);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
            }

            if (ot)
            {
                Position2D tar;
                if (Model.BallState.Speed.Y >= 0)
                    tar = GameParameters.OppGoalLeft;
                else
                {
                    tar = GameParameters.OppGoalRight;
                }
                onetouch.Perform(eng, Model, PositionerID, new SingleObjectState(PassTarget, Vector2D.Zero, 0), null, false, tar, shootSpeed, isChip, gotoOnetouch);
                Stop(Model, PasserID);
                positionerTarget = onetouch.OneTouchPoint;
                if (onetouch.OneTouchPoint.DistanceFrom(positionerRobot.Location) < 0.5)
                    gotoOnetouch = true;
            }

            if (f)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.3) { DrawPen = new Pen(Color.Red, 0.01f) });
            if (ot)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.5) { DrawPen = new Pen(Color.Blue, 0.01f) });
            DrawingObjects.AddObject(new Circle(positionerTarget, 0.1) { DrawPen = new Pen(Color.Red, 0.01f) });
            DrawingObjects.AddObject(new Circle(PassTarget, 0.2) { DrawPen = new Pen(Color.YellowGreen, 0.01f) });
            time++;
            return time == totalTime;
        }
        public bool ChipOneTouch(GameStrategyEngine eng, WorldModel Model, int PasserID, Position2D PasserInitilize, Position2D PassTarget, double passSpeed, kickPowerType passPowerType, int RotateDelay, int PositionerID, Position2D ShootTarget, double shootSpeed, bool isChip, kickPowerType shootPowerType, bool avoidOppZone)
        {
            double totalTime = 0;
       
            SingleObjectState passerRobot = Model.OurRobots[PasserID];
            SingleObjectState positionerRobot = Model.OurRobots[PositionerID];

            Line RobotTarget = new Line(positionerRobot.Location, ShootTarget);
            Line BallSpeed = new Line(Model.BallState.Location, Model.BallState.Location + Model.BallState.Speed.GetNormalizeToCopy(1));
            Position2D inter = Position2D.Zero;
 
           
            if (first)
            {
                positionerTarget = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(0.1);
                Vector2D rotateInitVec = (Model.BallState.Location - PassTarget).GetNormalizeToCopy(0.3);
                time2Pass = Planner.GetRotateTime(Model, PasserInitilize, PassTarget);
                time2Pass += (int)(Planner.GetMotionTime(Model,PasserID, passerRobot.Location, rotateInitVec + Model.BallState.Location));
                time2Pass += Planner.GetMotionTime(Model, PasserID, rotateInitVec + Model.BallState.Location, rotateInitVec.GetNormalizeToCopy(0.13) + Model.BallState.Location);
                time2Pass += RotateDelay;
                time2Pass = (int)(kRotateChip * time2Pass);
                time2Move = (int)(kChipOneTouchMove * Planner.GetMotionTime(Model, PositionerID, positionerRobot.Location, positionerTarget));
                first = false;
            }
            bool f = false;
            if (Model.BallState.Speed.Size > 0.3)
            {
                ot = true;
            }
            int dt = Math.Abs(time2Move - time2Pass);
            if (time2Pass > time2Move)
            {
                if (time < dt)
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, true, RotateDelay);
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, true, RotateDelay);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;

                }
            }
            else
            {
                if (time < dt)
                {
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, true, RotateDelay);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
            }
           
            if (ot)
            {
                Stop(Model, PasserID);
                Position2D target = (Model.BallState.Speed.Y >= 0) ? GameParameters.OppGoalLeft : GameParameters.OppGoalRight;
                onetouch.Perform(eng, Model, PositionerID, new SingleObjectState(PassTarget, Vector2D.Zero, 0), Model.OurRobots[PasserID], true, target, shootSpeed, isChip, gotoOnetouch);
                positionerTarget = onetouch.OneTouchPoint;
                if (onetouch.OneTouchPoint.DistanceFrom(positionerRobot.Location) < 0.5)
                    gotoOnetouch = true;
            }

            //if (f)
            //    DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.3) { DrawPen = new Pen(Color.Red, 0.01f) });
            //if(ot)
            //    DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.5) { DrawPen = new Pen(Color.Blue, 0.01f) });
            //DrawingObjects.AddObject(new Circle(positionerTarget, 0.1) { DrawPen = new Pen(Color.Red, 0.01f) });
            //DrawingObjects.AddObject(new Circle(PassTarget, 0.2) { DrawPen = new Pen(Color.YellowGreen, 0.01f) });
            time++;
            return time == totalTime;
        }
        public bool ChipOneTouch(GameStrategyEngine eng, WorldModel Model, int PasserID, double Teta, Position2D PassTarget, double passSpeed, kickPowerType passPowerType, int RotateDelay, int PositionerID, Position2D ShootTarget, double shootSpeed, bool isChip, kickPowerType shootPowerType, bool avoidOppZone)
        {
            double totalTime = 0;

            SingleObjectState passerRobot = Model.OurRobots[PasserID];
            SingleObjectState positionerRobot = Model.OurRobots[PositionerID];

            Line RobotTarget = new Line(positionerRobot.Location, ShootTarget);
            Line BallSpeed = new Line(Model.BallState.Location, Model.BallState.Location + Model.BallState.Speed.GetNormalizeToCopy(1));
            Position2D inter = Position2D.Zero;


            if (first)
            {
                positionerTarget = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(0.1);
                Vector2D rotateInitVec = (Model.BallState.Location - PassTarget).GetNormalizeToCopy(0.3);
                time2Pass = Planner.GetRotateTime(Teta);
                time2Pass += (int)(Planner.GetMotionTime(Model, PasserID, passerRobot.Location, rotateInitVec + Model.BallState.Location));
                time2Pass += Planner.GetMotionTime(Model, PasserID, rotateInitVec + Model.BallState.Location, rotateInitVec.GetNormalizeToCopy(0.13) + Model.BallState.Location);
                time2Pass += RotateDelay;
                time2Pass = (int)(kRotateChip * time2Pass);
                time2Move = (int)(kChipOneTouchMove * Planner.GetMotionTime(Model, PositionerID, positionerRobot.Location, positionerTarget));
                first = false;
            }
            bool f = false;
            if (Model.BallState.Speed.Size > 0.3)
            {
                ot = true;
            }
            int dt = Math.Abs(time2Move - time2Pass);
            if (time2Pass > time2Move)
            {
                if (time < dt)
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, true, RotateDelay);
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, true, RotateDelay);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;

                }
            }
            else
            {
                if (time < dt)
                {
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, Teta, passPowerType, passSpeed, true, RotateDelay);
                    Planner.Add(PositionerID, new SingleObjectState(positionerTarget, Vector2D.Zero, (float)(ShootTarget - positionerTarget).AngleInDegrees), PathType.UnSafe, false, true, true, avoidOppZone);
                    f = true;
                }
            }

            if (ot)
            {
                Stop(Model, PasserID);
                Position2D target = (Model.BallState.Speed.Y >= 0) ? GameParameters.OppGoalLeft : GameParameters.OppGoalRight;
                onetouch.Perform(eng, Model, PositionerID, new SingleObjectState(PassTarget, Vector2D.Zero, 0), Model.OurRobots[PasserID], true, target, shootSpeed, isChip, gotoOnetouch);
                positionerTarget = onetouch.OneTouchPoint;
                if (onetouch.OneTouchPoint.DistanceFrom(positionerRobot.Location) < 0.5)
                    gotoOnetouch = true;
            }

            if (f)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.3) { DrawPen = new Pen(Color.Red, 0.01f) });
            if (ot)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.5) { DrawPen = new Pen(Color.Blue, 0.01f) });
            DrawingObjects.AddObject(new Circle(positionerTarget, 0.1) { DrawPen = new Pen(Color.Red, 0.01f) });
            DrawingObjects.AddObject(new Circle(PassTarget, 0.2) { DrawPen = new Pen(Color.YellowGreen, 0.01f) });
            time++;
            return time == totalTime;
        }
        Position2D virtualTar = Position2D.Zero;
        public bool Cut(GameStrategyEngine eng, WorldModel Model, int PasserID, Position2D PasserInitilize, Position2D PassTarget, bool passIsChip, double passSpeed, kickPowerType passPowerType, int RotateDelay, int PositionerID, Position2D ShootTarget, double shootSpeed, bool isChip, kickPowerType shootPowerType)
        {
            double totalTime = 0;
            bool containPasser =Model.OurRobots.ContainsKey(PasserID);
            bool containPositioner =Model.OurRobots.ContainsKey(PositionerID);
            SingleObjectState passerRobot = (containPasser) ? Model.OurRobots[PasserID] : null;
            SingleObjectState positionerRobot = (containPositioner) ? Model.OurRobots[PositionerID] : null;

            if (first)
            {
                if (!containPasser || !containPositioner)
                    return false;
                Line RobotTarget = new Line(positionerRobot.Location, ShootTarget);
                Line BallSpeed = new Line(Model.BallState.Location, PassTarget);
                Position2D inter = Position2D.Zero;
                if (BallSpeed.IntersectWithLine(RobotTarget, ref inter))
                    positionerTarget = inter + (inter - ShootTarget).GetNormalizeToCopy(0.1);
                else
                    positionerTarget = PassTarget + (PassTarget - ShootTarget).GetNormalizeToCopy(0.1);

                Vector2D rotateInitVec = (Model.BallState.Location - PassTarget).GetNormalizeToCopy(0.3);
                time2Pass = Planner.GetRotateTime(Model, PasserInitilize, PassTarget);
                time2Pass += (int)(Planner.GetMotionTime(Model, PasserID, passerRobot.Location, rotateInitVec + Model.BallState.Location));
                time2Pass += Planner.GetMotionTime(Model, PasserID, rotateInitVec + Model.BallState.Location, rotateInitVec.GetNormalizeToCopy(0.13) + Model.BallState.Location);
                time2Pass += RotateDelay;
                time2Pass += (int)(k * (Model.BallState.Location.DistanceFrom(positionerTarget) / passSpeed) / StaticVariables.FRAME_PERIOD);
                time2Pass = (int)(kRotateCut * time2Pass);

                virtualTar = positionerRobot.Location + kExtendCut * (positionerTarget - positionerRobot.Location);
                time2Move = (int)(kCutMove * Planner.GetMotionTime(Model, PositionerID, positionerRobot.Location, virtualTar));
                first = false;
            }
            bool f = false;
            DrawingObjects.AddObject(new Circle(virtualTar, 0.06), "virtualTar");
            int dt = Math.Abs(time2Move - time2Pass);

            if (time2Pass > time2Move)
            {
                if (time < dt)
                {

                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, passIsChip, RotateDelay);
                }
                else
                {

                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, passIsChip, RotateDelay);
                    cutRole.CutIt(eng, Model, PositionerID, ShootTarget, shootSpeed, false);
                    f = true;
                }
            }
            else
            {
                if (time < dt)
                {
                    cutRole.CutIt(eng, Model, PositionerID, ShootTarget, shootSpeed, false);
                    f = true;
                }
                else
                {
                    Planner.AddRotate(Model, PasserID, PassTarget, PasserInitilize, passPowerType, passSpeed, passIsChip, RotateDelay);
                    cutRole.CutIt(eng, Model, PositionerID, ShootTarget, shootSpeed, false);
                    f = true;
                }
            }

            if (f)
                DrawingObjects.AddObject(new Circle(Position2D.Zero, 0.3) { DrawPen = new Pen(Color.Red, 0.01f) });
            DrawingObjects.AddObject(new Circle(positionerTarget, 0.1) { DrawPen = new Pen(Color.Red, 0.01f) });
            DrawingObjects.AddObject(new Circle(PassTarget, 0.2) { DrawPen = new Pen(Color.YellowGreen, 0.01f) });
            time++;
            return time == totalTime;
        }
        public void Stop(WorldModel Model, int RobotID)
        {
            SingleWirelessCommand s = new SingleWirelessCommand();
            s.W = 0;
            Vector2D prev = Vector2D.Zero;
            if (Model.lastVelocity.ContainsKey(RobotID))
                prev = GameParameters.RotateCoordinates(Model.lastVelocity[RobotID], Model.OurRobots[RobotID].Angle.Value);
            s.Vx = prev.X / 1.07;
            s.Vy = prev.Y / 1.07;
            Planner.Add(RobotID, s, false);
        }
    }
}
