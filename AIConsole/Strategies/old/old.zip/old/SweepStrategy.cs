﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;

namespace MRL.SSL.AIConsole.Strategies
{
    public class SweepStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        int passerID = 0;
        int kickerID = 0;
        int positionerID = 0;
        Position2D passPos = new Position2D(-2.5, -1.3);
        Position2D passerPos = Position2D.Zero;
        Position2D kickerPos = Position2D.Zero;
        Position2D positionerPos = Position2D.Zero;
        double passerAngle = 0;
        double kickerAngle = 0;
        double positionerAngle = 0;
        Synchronizer sync = new Synchronizer();
        bool first = true;

        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            sync.Reset();
            first = true;
            isInint = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.FirstPosition;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
            passPos.Y = -Math.Abs(passPos.Y) * Math.Sign(Model.BallState.Location.Y);
        }

        public override void FillInformation()
        {
            StrategyName = "Sweep";
            AttendanceSize = 3;
            About = "this is sweep strategy! (Pa na Pa)";
        }
        
        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        
        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            if (first)
            {
                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && passPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = passPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                positionerID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w != positionerID).ToList();
                if (list.Count > 0)
                    kickerID = list[0];

                first = false;
            }
            if (CurrentState == (int)State.FirstPosition)
            {
                Counter2++;
                if (Counter2 > 540 || Model.OurRobots[kickerID].Location.DistanceFrom(kickerPos) < 0.01 && Model.OurRobots[positionerID].Location.DistanceFrom(positionerPos) < 0.01 && Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01)
                    CurrentState = (int)State.SecondPosition;
            }
            else if (CurrentState == (int)State.SecondPosition)
            {
                if (Model.OurRobots[kickerID].Location.DistanceFrom(kickerPos) > 0.2)
                    Counter++;
                if (Counter > 180)
                    CurrentState = (int)State.Finish;
            }

            if (CurrentState == (int)State.FirstPosition)
            {
                passerPos = (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6) + Model.BallState.Location;
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;

                kickerPos = passerPos + new Vector2D(0.3, 0);
                kickerAngle = 180;

                positionerPos = passPos + new Vector2D(0.3, -0.1);
                positionerAngle = (GameParameters.OppGoalCenter - positionerPos).AngleInDegrees;
            }
            else if (CurrentState == (int)State.SecondPosition)
            {
                if (Model.OurRobots[kickerID].Location.DistanceFrom(kickerPos) > 0.2)
                {
                    positionerPos = kickerPos;
                    positionerAngle = 0;
                }
            }
        }
        
        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            if (CurrentState == (int)State.FirstPosition)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(kickerID, new SingleObjectState(kickerPos, Vector2D.Zero, (float)kickerAngle), PathType.Safe, true, true, true, true);
                Planner.Add(positionerID, new SingleObjectState(positionerPos, Vector2D.Zero, (float)positionerAngle), PathType.Safe, true, true, true, true);
            }
            if (CurrentState == (int)State.SecondPosition)
            {
                double dist = Model.BallState.Location.DistanceFrom(new Position2D(-3.025 + .80, 0));
                sync.ChipOneTouch(engine, Model, passerID, (Model.BallState.Location - passPos).GetNormalizeToCopy(0.1) + Model.BallState.Location, passPos, 1.2, kickPowerType.Speed, 20, kickerID, GameParameters.OppGoalCenter, 7, false, kickPowerType.Speed, true);
                Planner.Add(positionerID, new SingleObjectState(positionerPos, Vector2D.Zero, (float)positionerAngle), PathType.UnSafe, true, true, true, true);
            }
            Functions = new Dictionary<int, CommonDelegate>();
            return new Dictionary<int, RoleBase>();
        }
        
        public enum State
        {
            FirstPosition,
            SecondPosition,
            Finish
        }
    }
}
