﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.Planning.GamePlanner.Types;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class NearPassingStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        int Counter3 = 0;
        bool first = true;
        Synchronizer sync = new Synchronizer();
        Position2D passPos = new Position2D();
        Position2D passerPos = new Position2D();
        Position2D kickerFirstPos = new Position2D();
        int passerID = 0;
        double passerAngle = 0;
        int nearID = 0;
        double nearAngle = 0;
        Position2D nearPos = new Position2D();
        Position2D kickerPos = new Position2D();
        Position2D kickerLastPos = new Position2D();
        int kickerID = 0;
        double kickerAngle = 0;
        bool pass = true;
        int onetouchid = 0;
        bool chipTouch = false;
        int otherId = 0;
        Position2D otherPos = new Position2D();
        Position2D nearFirstPos = new Position2D();
        Position2D nearLastPos = new Position2D();
        public override void ResetState()
        {
            pass = true;
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            Counter3 = 0;
            sync.Reset();
            first = true;
            isInint = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.First;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
        }

        public override void FillInformation()
        {
            StrategyName = "Near";
            AttendanceSize = 3;
            About = "this is near strategy!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        Random rand = new Random();
        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            if (first)
            {
                kickerFirstPos = Model.BallState.Location + Vector2D.FromAngleSize(-Math.Sign(Model.BallState.Location.Y) * 45 * Math.PI / 180, 1);
                nearAngle = (GameParameters.OppGoalCenter - nearPos).AngleInDegrees;

                nearFirstPos = Model.BallState.Location + new Vector2D(1, 0);
                nearLastPos = Model.BallState.Location + Vector2D.FromAngleSize(-Math.Sign(Model.BallState.Location.Y) * 25 * Math.PI / 180, 1);
                kickerLastPos = new Position2D(Model.BallState.Location.X, -Math.Sign(Model.BallState.Location.Y) * 1.7);
                Obstacles obs = new Obstacles(Model);
                obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(), null);
                while (obs.Meet(new SingleObjectState(kickerLastPos, Vector2D.Zero, 0), 0.09))
                {
                    kickerLastPos = kickerLastPos + new Vector2D(0.1, 0.1);
                }
                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
                minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (item.Key != passerID && nearPos.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = nearPos.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                nearID = minidx;
                var list = Attendance.Keys.Where(w => w != passerID && w!= nearID).ToList();
                if (list.Count > 0)
                    kickerID = list[0];

                first = false;
            }
            if (CurrentState == (int)State.First)
            {
                Counter3++;
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[nearID].Location.DistanceFrom(nearPos) < 0.01 && Model.OurRobots[kickerID].Location.DistanceFrom(kickerPos) < 0.01)
                {
                    Counter++;
                }
                if (Counter3 > 420 || Counter > 60)
                {
                    CurrentState = (int)State.OneTouch;
                }
            }
            else if (CurrentState == (int)State.OneTouch)
            {
                Counter2++;
                if (Counter2 > 300)
                    CurrentState = (int)State.Finish;
            }
            if (CurrentState == (int)State.First)
            {
                kickerPos = kickerFirstPos;
                kickerAngle = 180;
                nearPos = nearFirstPos;
                passerPos = Model.BallState.Location + (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6);
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;
            }
            if (CurrentState == (int)State.OneTouch && pass)
            {
                if (engine.GameInfo.OurTeam.MarkingStatesToBall[nearID] == MarkingType.Open2Direct)
                {
                    nearPos = nearLastPos;
                    passPos = nearPos + (GameParameters.OppGoalCenter - nearPos).GetNormalizeToCopy(0.2);
                    onetouchid = nearID;
                    chipTouch = false;
                    otherId = kickerID;
                    otherPos = kickerLastPos;
                }
                else
                {
                    nearPos = nearLastPos;
                    passPos = kickerLastPos;
                    onetouchid = kickerID;
                    if (engine.GameInfo.OurTeam.MarkingStatesToBall[kickerID] == MarkingType.Open2Direct ||
                        engine.GameInfo.OurTeam.MarkingStatesToTarget[kickerID] == (MarkingType.Open2Direct) ||
                        engine.GameInfo.OurTeam.MarkingStatesToBall[kickerID] == (MarkingType.Near | MarkingType.Open2Direct))
                    {
                        chipTouch = true;
                    }
                    otherId = nearID;
                    otherPos = nearPos;
                }
                pass = false;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>(Model.OurRobots.Count);
            Functions = new Dictionary<int, CommonDelegate>();


            if (CurrentState == (int)State.First)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(nearID, new SingleObjectState(nearPos, Vector2D.Zero, (float)nearAngle), PathType.Safe, true, true, true, true);
                Planner.Add(kickerID, new SingleObjectState(kickerPos, Vector2D.Zero, (float)kickerAngle), PathType.Safe, true, true, true, true);
            }
            if (CurrentState == (int)State.OneTouch)
            {
                if (chipTouch)
                    sync.ChipOneTouch(engine, Model, passerID, 90, passPos, Model.BallState.Location.DistanceFrom(passPos) / 3, kickPowerType.Speed, 30, onetouchid, GameParameters.OppGoalCenter, 8, false, kickPowerType.Speed, true);
                else
                {
                    if (passPos == kickerLastPos)
                        sync.DirectOneTouch(engine, Model, passerID, 90, passPos, 3.5, kickPowerType.Speed, 30, onetouchid, GameParameters.OppGoalCenter, 8, false, kickPowerType.Speed, true);
                    else
                    {
                        Planner.AddRotate(Model, passerID, passPos, 90, kickPowerType.Speed, 2, false, 30);
                        if (Model.BallState.Speed.Size > 0.1)
                        {
                            if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, nearID, typeof(OneTouchRole)))
                                Functions[nearID] = (eng, wmd) => GetRole<OneTouchRole>(nearID).Perform(eng, wmd, nearID, null, false, GameParameters.OppGoalCenter, 8, false);
                        }
                        else
                            Planner.Add(nearID, new SingleObjectState(nearPos, Vector2D.Zero, (float)nearAngle), PathType.UnSafe, true, true, true, true);
                        Planner.AddKick(nearID, true);
                    }
                }
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) > 0.07)
                    Planner.Add(otherId, new SingleObjectState(otherPos, Vector2D.Zero, (float)(GameParameters.OppGoalCenter - otherPos).AngleInDegrees), PathType.UnSafe, true, true, true, true);
            }


            PreviouslyAssignedRoles = CurrentlyAssignedRoles;
            return CurrentlyAssignedRoles;
        }
        public enum State
        {
            First,
            OneTouch,
            Finish
        }
    }
}
