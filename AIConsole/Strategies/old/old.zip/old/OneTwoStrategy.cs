﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.CommonClasses.MathLibrary;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.AIConsole.Roles;

namespace MRL.SSL.AIConsole.Strategies
{
    public class OneTwoStrategy:StrategyBase
    {
        public override void InitializeStates(GameStrategyEngine engine, WorldModel Model, Dictionary<int, SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = 0;
            InitialState = 0;
            FinalState = 6;
            TrapState = 6;
        }

        public override void FillInformation()
        {
            StrategyName = "OneTwo";
            AttendanceSize = 2;
            About = "In this strategy robot pass and run in space ....";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, WorldModel Model, ref GameStatus Status)
        {
            if (CurrentState == (int)states.finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }

        private enum states
        {
            firstPosition = 0,
            passForReflect = 1,
            passForDirect = 2,
            shootDirect = 3,
            shootReflect = 4,
            reflect = 5,
            finish = 6
        }

        Position2D pos1 = new Position2D();
        Position2D pos2 = new Position2D();
        Position2D pos3 = new Position2D();

        Position2D pos2Pass = new Position2D();
        double nearTresh = 0.3;
        int counter1 = 0,counter2 = 0;

        int reflectorId = 0;
        int kickerId = 0;
        int positionerId = 0;
        


        public override void DetermineNextState(GameStrategyEngine engine, WorldModel Model)
        {
            SingleObjectState reflector = new SingleObjectState();
            SingleObjectState kicker = new SingleObjectState();
            SingleObjectState positioner = new SingleObjectState();
            SingleObjectState ball  = Model.BallState;

            if (CurrentState == (int)states.firstPosition)
            {
                pos2 = new Position2D(-2.8, Model.BallState.Location.Y);
                pos3 = new Position2D(0, -Math.Sign(Model.BallState.Location.Y) * 1.9);
                pos1 = (pos3 - ball.Location).GetNormalizeToCopy(0.2) + ball.Location;

                if (pos2.DistanceFrom(reflector.Location) < nearTresh 
                    && pos1.DistanceFrom(kicker.Location) < 0.05 
                    && pos3.DistanceFrom(positioner.Location) < nearTresh)
                {
                    Obstacles obs = new Obstacles();
                    obs.AddObstacle(1, 0, 0, 0, Model.OurRobots.Keys.ToList(),null);
                    if (obs.Meet(new SingleObjectState(ball.Location, Vector2D.Zero, null),
                        new SingleObjectState(pos3, Vector2D.Zero, null), 0.1))
                    {
                        CurrentState = (int)states.passForDirect;
                    }
                    else
                    {
                        CurrentState = (int)states.passForReflect;
                    }
                }

            }
            if (CurrentState == (int)states.passForDirect)
            {
                if (ball.Speed.Size > 0.2)
                {
                    CurrentState = (int)states.shootDirect;
                    counter1 = 0;
                }
            }

            if (CurrentState == (int)states.shootDirect)
            {
                counter1++;
                if (counter1 > 60)
                {
                    CurrentState = (int)states.finish;
                }
            }

            if (CurrentState == (int)states.passForReflect)
            {
                if (ball.Speed.Size > 0.2)
                {
                    CurrentState = (int)states.reflect;
                }
            }

            if (CurrentState == (int)states.reflect)
            {
                if (ball.Speed.InnerProduct(pos2Pass - pos2) > 0)
                {
                    CurrentState = (int)states.shootReflect;
                }

                if (ball.Speed.Size < 0.4)
                {
                    CurrentState = (int)states.finish;
                }
            }
            if (CurrentState == (int)states.shootReflect)
            {
                counter2++;
                if (counter2 > 60)
                {
                    CurrentState = (int)states.finish;
                }
            }


            
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            SingleObjectState reflector = new SingleObjectState();
            SingleObjectState kicker = new SingleObjectState();
            SingleObjectState positioner = new SingleObjectState();
            SingleObjectState ball = Model.BallState;
            Dictionary<int, RoleBase> CurrentlyAssignedRoles = new Dictionary<int, RoleBase>();
            Functions = new Dictionary<int, CommonDelegate>();

            if (CurrentState == (int)states.firstPosition)
            {
                Planner.Add(kickerId, new SingleObjectState(pos1, Vector2D.Zero, (float)(pos3 - pos1).AngleInDegrees), PathType.UnSafe, true, true, true);
                Planner.Add(reflectorId, new SingleObjectState(pos2, Vector2D.Zero, (float)(ball.Location - pos2).AngleInDegrees), PathType.UnSafe, true, true, true);
                Planner.Add(positionerId, new SingleObjectState(pos3, Vector2D.Zero, (float)(ball.Location - pos3).AngleInDegrees), PathType.UnSafe, true, true, true);
            }

            if (CurrentState == (int)states.passForDirect)
            {
                Planner.AddRotate(Model, kickerId, pos3, pos1, kickPowerType.Speed, 4, false);
                Planner.Add(reflectorId, new SingleObjectState(pos2, Vector2D.Zero, (float)(ball.Location - pos2).AngleInDegrees), PathType.UnSafe, true, true, true);
                Planner.Add(positionerId, new SingleObjectState(pos3, Vector2D.Zero, (float)(ball.Location - pos3).AngleInDegrees), PathType.UnSafe, true, true, true);
            }

            if (CurrentState == (int)states.shootDirect)
            {
                Planner.AddRotate(Model, kickerId, pos3, pos1, kickPowerType.Speed, 4, false);
                Planner.Add(reflectorId, new SingleObjectState(pos2, Vector2D.Zero, (float)(ball.Location - pos2).AngleInDegrees), PathType.UnSafe, true, true, true);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, positionerId, typeof(OneTouchRole)))
                    Functions[positionerId] = (eng, wmd) => GetRole<OneTouchRole>(positionerId).Perform(eng, wmd, positionerId,null,false, GameParameters.OppGoalCenter, Program.MaxKickSpeed, false);
            }

            if (CurrentState == (int)states.passForReflect)
            {
                Planner.AddRotate(Model, kickerId, pos3, pos2, kickPowerType.Speed, 4, false);
                Planner.Add(reflectorId, new SingleObjectState(pos2, Vector2D.Zero, (float)(ball.Location - pos2).AngleInDegrees), PathType.UnSafe, true, true, true);
                Planner.Add(positionerId, new SingleObjectState(pos3, Vector2D.Zero, (float)(ball.Location - pos3).AngleInDegrees), PathType.UnSafe, true, true, true);
            }

            if (CurrentState == (int)states.reflect)
            {
                Planner.Add(positionerId, new SingleObjectState(new Position2D(2,0), Vector2D.Zero, 180), PathType.UnSafe, true, true, true);
                Planner.Add(kickerId, new SingleObjectState(pos2Pass, Vector2D.Zero, 180), PathType.UnSafe, true, true, true);
                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, reflectorId, typeof(OneTouchRole)))
                    Functions[reflectorId] = (eng, wmd) => GetRole<OneTouchRole>(reflectorId).Perform(eng, wmd, reflectorId,null,false, pos2Pass, 4, false);
            }

            if (CurrentState == (int)states.shootReflect)
            {
                Planner.Add(positionerId, new SingleObjectState(new Position2D(2, 0), Vector2D.Zero, 180), PathType.UnSafe, true, true, true);
                Planner.Add(reflectorId, new SingleObjectState(pos2Pass, Vector2D.Zero, 180), PathType.UnSafe, true, true, true);

                if (StaticRoleAssigner.AssignRole(engine, Model, PreviouslyAssignedRoles, CurrentlyAssignedRoles, kickerId, typeof(OneTouchRole)))
                    Functions[kickerId] = (eng, wmd) => GetRole<OneTouchRole>(kickerId).Perform(eng, wmd, kickerId,null,false, GameParameters.OppGoalCenter, Program.MaxKickSpeed, false);
            }
            
            return CurrentlyAssignedRoles;
        }
        public override void ResetState()
        {
            CurrentState = InitialState;
            counter1 = 0;
            counter2 = 0;
        }
    }
}
