﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MRL.SSL.AIConsole.Engine;
using MRL.SSL.GameDefinitions;
using MRL.SSL.Planning.MotionPlanner;
using MRL.SSL.CommonClasses.MathLibrary;

namespace MRL.SSL.AIConsole.Strategies
{
    public class SimplePassingStrategy:StrategyBase
    {
        int Counter = 0;
        int Counter2 = 0;
        bool first = true;
        Synchronizer sync = new Synchronizer();
        public override void ResetState()
        {
            CurrentState = InitialState;
            Counter = 0;
            Counter2 = 0;
            Counter3 = 0;
            sync.Reset();
            first = true;
            isInint = false;
        }

        public override void InitializeStates(GameStrategyEngine engine, GameDefinitions.WorldModel Model, Dictionary<int, GameDefinitions.SingleObjectState> attendance)
        {
            Attendance = attendance;
            CurrentState = (int)State.First;
            InitialState = 0;
            FinalState = 2;
            TrapState = 2;
        }

        public override void FillInformation()
        {
            StrategyName = "SimplePassing";
            AttendanceSize = 2;
            About = "this is Simple Passing strategy!";
        }

        public override bool IsFeasiblel(GameStrategyEngine engine, GameDefinitions.WorldModel Model, ref GameDefinitions.GameStatus Status)
        {
            if (CurrentState == (int)State.Finish)
            {
                Status = GameStatus.Normal;
                return false;
            }
            return true;
        }
        Random rand = new Random();
        Position2D passPos = new Position2D();
        double passerAngle = 0;
        double kickerAngle = 0;
        Position2D passerPos = Position2D.Zero;
        Position2D kickerPos = Position2D.Zero;
        int passerID = 0;
        int kickerID = 0;
        int Counter3 = 0;
        public override void DetermineNextState(GameStrategyEngine engine, GameDefinitions.WorldModel Model)
        {
            if (first)
            {
                Obstacles obs = new Obstacles(Model);
                obs.AddObstacle(1,0,0,0,Model.OurRobots.Keys.ToList(),null);
                double r = rand.NextDouble();
                int count = 0;
                do
                {
                    count++;
                    passPos = new Position2D(-(rand.NextDouble() * (2.7 - 1) + 1), -Math.Sign(Model.BallState.Location.Y) * ((rand.NextDouble() * (1.85 - 1) + 1)));
                } while (count < 10 && obs.Meet(new SingleObjectState(passPos, Vector2D.Zero, 0), 0.09));
                

                int minidx = 0;
                double minDist = double.MaxValue;
                foreach (var item in Attendance)
                {
                    if (Model.BallState.Location.DistanceFrom(item.Value.Location) < minDist)
                    {
                        minDist = Model.BallState.Location.DistanceFrom(item.Value.Location);
                        minidx = item.Key;
                    }
                }
                passerID = minidx;
              
                var list = Attendance.Keys.Where(w => w != passerID ).ToList();
                if (list.Count > 0)
                    kickerID = list[0];

                first = false;
            }
            if (CurrentState == (int)State.First)
            {
                Counter3++;
                if (Model.OurRobots[passerID].Location.DistanceFrom(passerPos) < 0.01 && Model.OurRobots[kickerID].Location.DistanceFrom(kickerPos) < 0.01)
                {
                    Counter2++;
                }
                if (Counter2 > 60 || Counter3 > 420)
                    CurrentState = (int)State.Pass;
            }
            else if (CurrentState == (int)State.Pass)
            {
                Counter++;
                if (Counter > 300)
                    CurrentState = (int)State.Finish;
            }

            if (CurrentState == (int)State.First)
            {
                passerPos = Model.BallState.Location + (GameParameters.OurGoalCenter - Model.BallState.Location).GetNormalizeToCopy(0.6);
                passerAngle = (Model.BallState.Location - passerPos).AngleInDegrees;

                kickerPos = new Position2D(1, Math.Sign(passPos.Y) * 1.7);//passerPos + new Vector2D(0.3, 0);
                kickerAngle = (Model.BallState.Location - kickerPos).AngleInDegrees;
            }
        }

        public override Dictionary<int, RoleBase> RunStrategy(GameStrategyEngine engine, GameDefinitions.WorldModel Model, out Dictionary<int, CommonDelegate> Functions)
        {
            if (CurrentState == (int)State.First)
            {
                Planner.Add(passerID, new SingleObjectState(passerPos, Vector2D.Zero, (float)passerAngle), PathType.UnSafe, true, true, true, true);
                Planner.Add(kickerID, new SingleObjectState(kickerPos, Vector2D.Zero, (float)kickerAngle), PathType.Safe, true, true, true, true);
            }
            if (CurrentState == (int)State.Pass)
            {
                sync.ChipOneTouch(engine, Model, passerID, Model.BallState.Location + new Vector2D(0.3, 0), passPos, Model.BallState.Location.DistanceFrom(passPos) / 3, kickPowerType.Speed, 60, kickerID, GameParameters.OppGoalCenter, 7, false, kickPowerType.Speed, true);
            }
            Functions = new Dictionary<int, CommonDelegate>();
            return new Dictionary<int, RoleBase>();
        }
        public enum State
        {
            First,
            Pass,
            Finish
        }
    }
}
